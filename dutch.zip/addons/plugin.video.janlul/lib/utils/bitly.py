import urllib2, re, base64

basesite = 'http://www.vdia.solutions/'

def getLink(streamName):
    pagecontent = getPage(basesite + streamName)
    base64 = getBaseEncodedString(pagecontent)
    return getStreamUrl(base64)
    
def getIdByUrl(url):
    _regex_getM3u = re.compile("http://(.*?)/flv/(.*?)/1.flv", re.DOTALL)
    streamId = _regex_getM3u.search(url).group(2)
    return streamId
	
def getPage(page):
    url = page
    try:
        #headers = {'User-agent' : 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:28.0) Gecko/20100101 Firefox/28.0'}
        req = urllib2.Request(url ,None)
        response = urllib2.urlopen(req)
        data = response.read()
        response.close()
        return data
    except urllib2.URLError, e:
        return ''
        print('We failed to open '+url)


def getBaseEncodedString(streamPage):
    try:
        _regex_encodedstring = re.compile("window\.atob\(\'(.*?)\'\)" , re.DOTALL)
        baseEncoded = _regex_encodedstring.search(streamPage).group(1)
        return baseEncoded
    except AttributeError:
        return ''

def getStreamUrl(baseEncoded):
    return base64.b64decode(baseEncoded)

def getAceHash(webpage):
    pagecontent = getPage(webpage)
    # search for: http://torrentstream.org/embed/{ACEHASH}?autoplay=1
    _regex_getM3u = re.compile("http://torrentstream.org/embed/(.*?)\?autoplay=1", re.DOTALL)
    streamId = _regex_getM3u.search(pagecontent).group(1)
    return streamId
	
def resolveTorrentTv(webpage):
    pagecontent = getPage(webpage)
    # Search for loadPlayer("{acehash}",{autoplay: true});
    _regex_getM3u = re.compile("loadPlayer\(\"(.*?)\",{autoplay: true}", re.DOTALL)
    streamId = _regex_getM3u.search(pagecontent).group(1)
    return streamId	