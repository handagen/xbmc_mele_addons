# rtmp://188.40.127.6:1935/live/dazsports

def addRtmpItem(name, rtmpFile):
    xbmcutil.addMenuItem(displayName, rtmpFile, 'true')