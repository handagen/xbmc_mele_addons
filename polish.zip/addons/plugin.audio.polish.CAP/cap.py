# -*- coding: utf-8 -*-
import os, string, StringIO, cookielib
import urllib, urllib2, re, sys
import xbmcaddon, xbmc, math
import traceback, xbmcgui

cap = xbmcaddon.Addon()
scriptID = cap.getAddonInfo('id')
scriptname = cap.getAddonInfo('name')
language = cap.getLocalizedString
dbg = cap.getSetting('default_debug') in ('true')

SERVICE = 'cap'
BASE_RESOURCE_PATH = os.path.join( cap.getAddonInfo('path'), "resources" )
sys.path.append( os.path.join( BASE_RESOURCE_PATH, "lib" ) )
BASE_IMAGE_PATH = 'http://sd-xbmc.org/repository/xbmc-addons/'
COOKIEFILE = cap.getAddonInfo('path') + os.path.sep + "cookies" + os.path.sep + SERVICE + ".cookie"
MAINLOGO = BASE_IMAGE_PATH + "chomikuj.png"
MAINURL = 'http://chomikuj.pl'
THUMB_NEXT = BASE_IMAGE_PATH + "dalej.png"

import sdLog, sdSettings, sdParser, sdErrors
import downloader, sdCommon, sdNavigation

log = sdLog.pLog()

username = cap.getSetting('cap_login')
password = cap.getSetting('cap_password')
folder = cap.getSetting('cap_folder')
dstpath = cap.getSetting('default_dstpath')
Spath = os.path.join(dstpath, SERVICE)
cj = cookielib.LWPCookieJar()

class CAP:
    def __init__(self):
	log.info('Loading ' + SERVICE)
	self.settings = sdSettings.TVSettings()
	self.parser = sdParser.Parser()
	self.cm = sdCommon.common()
	self.exception = sdErrors.Exception()
	self.gui = sdNavigation.sdGUI()

    def getToken(self):
	query_data = { 'url': MAINURL, 'use_host': False, 'use_cookie': True, 'save_cookie': True, 'load_cookie': False, 'cookiefile': COOKIEFILE, 'use_post': False, 'return_data': True}
	try:
	    data = self.cm.getURLRequestData(query_data)
	except Exception, exception:
	    traceback.print_exc()
	    self.exception.getError(str(exception))
	    exit()
	match = re.compile('name="__RequestVerificationToken" type="hidden" value="(.+?)"').findall(data)
	if len(match) > 0:
            token = match[0]
            return token
        
    def listsPlaylistMenu(self,page):
	query_data = { 'url': page, 'use_host': False, 'use_cookie': True, 'save_cookie': True, 'load_cookie': True, 'cookiefile': COOKIEFILE, 'use_post': False, 'return_data': True}
	try:
	    data = self.cm.getURLRequestData(query_data)
	except Exception, exception:
	    traceback.print_exc()
	    self.exception.getError(str(exception))
	    exit()
	match = re.compile('id="foldersList"(.+?)class="clear"', re.DOTALL).findall(data)
	if len(match) > 0:
            match2 = re.compile('href="(.+?)" rel=".+?" title="(.+?)">').findall(match[0])
            if len(match2) > 0:
                for i in range(len(match2)):
                    title = self.cm.html_entity_decode(match2[i][1])
                    url = MAINURL + match2[i][0]
                    params = {'service': SERVICE, 'name': 'kate', 'title': title, 'page': url, 'icon': MAINLOGO}
                    self.gui.addDir(params)
	match = re.compile('<div id="listView"(.+?)<div id="folderActionButtos">', re.DOTALL).findall(data)
	if len(match) > 0:
            match2 = re.compile('data-url="http://chomikuj.pl.+?,(.+?).mp3" data-title="(.+?)">').findall(match[0])
            if len(match2) > 0:
                for i in range(len(match2)):
                    title = self.cm.html_entity_decode(match2[i][1])
                    url = 'http://chomikuj.pl/Audio.ashx?id=' + match2[i][0] + '&type=2&tp=mp3'
                    params = {'service': SERVICE, 'dstpath': dstpath, 'title': title, 'page': url, 'icon': MAINLOGO}
                    self.gui.playVideo(params)
	match = re.compile('class="current">.+?</li><li><a href="(.+?)" class=""').findall(data)
	if len(match) > 0:
            title = 'Następna strona'
            url = MAINURL + match[0]
            params = {'service': SERVICE, 'name': 'kate', 'title': title, 'page': url, 'icon': MAINLOGO}
            self.gui.addDir(params)
	self.gui.endDir(False)

    def getUrl(self, url):
        opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))
        cj.load(COOKIEFILE, ignore_discard = True)
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; rv:17.0) Gecko/20100101 Firefox/17.0')
        response = opener.open(req)
        data = response.geturl()
        response.close()
        return data

    def showListOptions(self):
	params = self.parser.getParams()
	name = self.parser.getParam(params, "name")
	title = self.parser.getParam(params, "title")
	category = self.parser.getParam(params, "category")
	page = self.parser.getParam(params, "page")
	icon = self.parser.getParam(params, "icon")
	link = self.parser.getParam(params, "url")
	service = self.parser.getParam(params, "service")
	action = self.parser.getParam(params, "action")
	path = self.parser.getParam(params, "path")

	self.parser.debugParams(params, dbg)
                       
    #LOGOWANIE
	if name == None:
            if username == '':
                d = xbmcgui.Dialog()
                d.ok('Brak nazwy CHOMIKA!', 'Wpisz w ustawieniach wtyczki nazwę użytkownika', 'aby korzystać z wtyczki.')
            else:
                token = self.getToken()
                if password == '': loginData = {}
                else: loginData = { 'Login' : username, '__RequestVerificationToken' : token, 'Password' : password, 'ReturnUrl' : '' }
                self.cm.requestLoginData(MAINURL + "/action/Login/TopBarLogin", 'Pliki użytkownika', COOKIEFILE, loginData)
    #MAIN MENU
                self.listsPlaylistMenu(MAINURL + '/' +username+ '/'+ folder)
    #MP3 LIST	    
	if name == 'kate':
	    self.listsPlaylistMenu(page)
    #ODTWÓRZ AUDIO
	if name == 'playSelectedVideo':
            linkAudio = self.getUrl(page)
	    self.gui.LOAD_AND_PLAY_VIDEO(linkAudio, title)
    #POBIERZ
	if action == 'download' and link !='':
	    if link.startswith('http://'):
	        linkAudio = self.getUrl(link)
		if linkAudio != False:
                    self.cm.checkDir(os.path.join(dstpath, SERVICE))
		    dwnl = downloader.Downloader()
		    dwnl.getFile({ 'title': title[:50], 'url': linkAudio, 'path': path })

init = CAP()
init.showListOptions()
