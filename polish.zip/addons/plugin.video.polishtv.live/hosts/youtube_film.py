# -*- coding: utf-8 -*-
import os,sys,xbmcaddon

ptv=xbmcaddon.Addon(sys.modules["__main__"].scriptID)

BASE_RESOURCE_PATH=os.path.join(ptv.getAddonInfo('path'),"../resources")
sys.path.append(os.path.join(BASE_RESOURCE_PATH,"lib"))

import yt_channels,sdParser

SERVICE='youtube_film'
MENU_TAB=[
	["BB Media", "yt_bbmedia.png", 'UCFh_8rlN5NDm98XyYO_oF4g'],
	["Filmowisko", "yt_filmowisko.png", 'UCnCqkAxYvZJVy3vxws_pdgg'],
	["Media Distribution - Bajki dla dzieci", "yt_mediad_bajki.png", 'UCQ2YO3snlAQhdk9NS5_cl2A'],
	["Media Distribution - Filmy", "yt_mediad.png", 'UCpqFtaACYWbQo55tNcEyQ6Q'],
	["Mega Content", "yt_megacontent.png", 'UCoJ3SGh7dhJfB7CIIzQyJ8g'],	
	["Polska Kronika Filmowa", "kronikafilmowa.png", 'UCqH0cdN4omTBTB-8gNJlWNA'],
	["Sala kinowa", "yt_salakinowa.png", 'UCMy42eSUu30ULX_VmnxiQLA'],
	["Studio Filmowe KADR", "studiokadr.png", 'UCAskl5pFqXmRv33qLaiXR7Q'],
	["Studio Filmowe TOR", "studiotor.png", 'UCalRj86akc7Jr2wLUlOHnqw'],
	["Studio Filmów Rysunkowych", "studiorysunkowych.png", 'UCfXtDCs237pyDFCBIQR46yw'],
	["Studio Miniatur Filmowych", "studiominiatur.png", 'UCCd_I2mXkZ5LcP02cDx1ryw'],
#	["Filmy w języku angielskim", "youtube.png", 'SBae7jiISxYlc']
]

class YouTubeFilm:
    def __init__(self):
        self.yt=yt_channels.youtubeChannels(SERVICE,MENU_TAB)
    def handleService(self):
        parser=sdParser.Parser()
        self.yt.handleService(parser.getParams())