# -*- coding: utf-8 -*-
import os, string, StringIO
import urllib, urllib2, re, sys
import xbmcaddon, xbmcgui
import traceback, xbmc

scriptID = sys.modules[ "__main__" ].scriptID
ptv = xbmcaddon.Addon(scriptID)

BASE_IMAGE_PATH = 'http://sd-xbmc.org/repository/xbmc-addons/'
BASE_RESOURCE_PATH = os.path.join( ptv.getAddonInfo('path'), "../resources" )
sys.path.append( os.path.join( BASE_RESOURCE_PATH, "lib" ) )

import sdLog, sdParser, urlparser, sdCommon, sdNavigation, sdErrors, downloader
import maxvideo

log = sdLog.pLog()

dbg = sys.modules[ "__main__" ].dbg
dstpath = ptv.getSetting('default_dstpath')

HOST = 'Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.9.2.18) Gecko/20110621 Mandriva Linux/1.9.2.18-0.1mdv2010.2 (2010.2) Firefox/3.6.18'
HEADER = {'User-Agent': HOST, 'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'}
SERVICE = 'bestplayer'
LOGOURL = BASE_IMAGE_PATH + SERVICE + '.png'
THUMB_NEXT = BASE_IMAGE_PATH + 'dalej.png'

MAINURL = 'http://bestplayer.tv/'
TOP_LINK = MAINURL + 'top100/'
HOT_LINK = MAINURL + 'hot/'

MENU_TAB = {
    1: "Lektor",
    2: "Napisy",
    3: "Premiery",
    4: "Najlepsze filmy",
    5: "Gorące tytuły ostatnich 30 dni",
    6: "Data wydania",
    7: "Wyszukaj",
    8: "Historia wyszukiwania"
}

class BestPlayer:
    def __init__(self):
	log.info('Loading ' + SERVICE)
	self.parser = sdParser.Parser()
	self.up = urlparser.urlparser()
	self.cm = sdCommon.common()
	self.history = sdCommon.history()
	self.exception = sdErrors.Exception()
	self.gui = sdNavigation.sdGUI()

    def setTable(self):
    	return MENU_TAB

    def listsMainMenu(self, table):
	for num, val in table.items():
	    params = {'service': SERVICE, 'name': 'main-menu','category': val, 'title': val, 'icon': LOGOURL}
	    self.gui.addDir(params)
	self.gui.endDir()

    def listsCategoriesMenu(self, category, url):
	query_data = { 'url': MAINURL + 'filmy/', 'use_host': False, 'use_cookie': False, 'use_post': False, 'return_data': True, 'use_header': True, 'header': HEADER  }
	try:
	    data = self.cm.getURLRequestData(query_data)
	except Exception, exception:
	    traceback.print_exc()
	    self.exception.getError(str(exception))
	    exit()
	if category == 'lektor':
	    match = re.compile('<a href="(.+?)z-lektorem.html" title="Filmy.+?"><span class="float-left">(.+?)</span>').findall(data)
	    link = 'z-lektorem-strona-1.html'
	elif category == 'napisy':
	    match = re.compile('<a href="(.+?)z-napisami.html" title="Filmy.+?"><span class="float-left">(.+?)</span>').findall(data)
	    link = 'z-napisami-strona-1.html'
	elif category == 'premiery':
	    match = re.compile('<a href="(.+?)premiery.html" title="Filmy.+?"><span class="float-left">(.+?)</span>').findall(data)
	    link = 'premiery-strona-1.html'
	elif category == 'data':
	    match = re.compile('<a href="filmy/rok(.+?).html" title=".+?"><span class="float-left">(.+?)</span>').findall(data)
	    link = '-strona-1.html'
	if len(match) > 0:
	    for i in range(len(match)):
		params = {'service': SERVICE, 'name': 'submenu', 'title': match[i][1], 'page': url + match[i][0] + link, 'icon': LOGOURL}
		self.gui.addDir(params)
	self.gui.endDir()

    def listsMovies(self, url, category):
	query_data = { 'url': url, 'use_host': False, 'use_cookie': False, 'use_post': False, 'return_data': True, 'use_header': True, 'header': HEADER  }
	try:
	    data = self.cm.getURLRequestData(query_data)
	except Exception, exception:
	    traceback.print_exc()
	    self.exception.getError(str(exception))
	    exit()
	if category == 'top100' or 'hot':
	    match = re.compile('<div class="movie-cover fl">.+?<a class="trigger.+?" href="(.+?)" title=""><img src="(.+?)" height="140" alt="okladka"/></a>.+?<h2>.+?>(.+?)</a></h2>.+?class="p5 film-dsc" style="min-height: 70px; ">(.+?)</div>', re.DOTALL).findall(data)
	    link = MAINURL
	if category == 'regular':
	    match = re.compile('<div class="movie-cover fl">.+?<a href="(.+?)" title=""><img src="(.+?)" height="140" alt="okladka"/></a>.+?<h2>.+?>(.+?)</a></h2>.+?<div class="p5 film-dsc" style="min-height: 70px;">(.+?)</div>', re.DOTALL).findall(data)
	    link = ''
	if len(match) > 0:
	    for i in range(len(match)):
		params = {'service': SERVICE, 'dstpath': dstpath, 'title': self.cm.html_entity_decode(match[i][2]), 'page': link + match[i][0], 'icon': match[i][1], 'plot': self.cm.html_entity_decode(match[i][3])}
		self.gui.playVideo(params)
	match = re.compile('<li class="round "><a href="(.+?)" class="next"></a></li>').findall(data)
	if len(match) > 0:
	    params = {'service': SERVICE, 'name': 'nextpage', 'title': 'Następna strona', 'page': MAINURL + match[0], 'icon': THUMB_NEXT}
	    self.gui.addDir(params)
	self.gui.endDir(False, 'movies', 'MediaInfo')

    def listsHistory(self, table):
	for i in range(len(table)):
	    if table[i] <> '':
		params = {'service': SERVICE, 'name': 'history', 'title': table[i],'icon': LOGOURL}
		self.gui.addDir(params)
	self.gui.endDir()

    def searchTab(self, url):
	query_data = { 'url': url, 'use_host': False, 'use_cookie': False, 'use_post': False, 'return_data': True, 'use_header': True, 'header': HEADER  }
	try:
	    link = self.cm.getURLRequestData(query_data)
	except Exception, exception:
	    traceback.print_exc()
	    self.exception.getError(str(exception))
	    exit()
        match = re.compile('<div class="movie-cover fl">.+?<a href="(.+?)" title=""><img src="(.+?)" height=".+?" alt="okladka"/></a>.+?<h2><a href=".+?">(.+?)</a></h2>.+?<div class="p5 film-dsc".+?">(.+?)</div>', re.DOTALL).findall(link)
	if len(match) > 0:
	    for i in range(len(match)):
		params = {'service': SERVICE, 'dstpath': dstpath, 'title': self.cm.html_entity_decode(match[i][2]), 'page': match[i][0], 'icon': match[i][1], 'plot': self.cm.html_entity_decode(match[i][3])}
		self.gui.playVideo(params)
	match2 = re.compile('<li class="round "><a href="(.+?)" class="next"></a></li>').findall(link)
	if len(match2) > 0:
	    params = {'service': SERVICE, 'name': 'nextpage', 'title': 'Następna strona', 'page': MAINURL + match2[0], 'icon': THUMB_NEXT}
	    self.gui.addDir(params)
	self.gui.endDir(False, 'movies', 'MediaInfo')

    def getVideoID(self,url):
	videoID = ''
	query_data = { 'url': url, 'use_host': False, 'use_cookie': False, 'use_post': True, 'return_data': True, 'use_header': True, 'header': HEADER  }
	try:
	    link = self.cm.getURLRequestData(query_data)
	except Exception, exception:
	    traceback.print_exc()
	    self.exception.getError(str(exception))
	    exit()
	match = re.compile('<iframe src="(.+?)" style="border:0px; width: 740px; height: 475px;" scrolling="no"></iframe>').findall(link)
	if len(match) > 0:
	    videoID = match[0]
	return videoID

    def handleService(self):
	params = self.parser.getParams()
	name = self.parser.getParam(params, "name")
	title = self.parser.getParam(params, "title")
	category = self.parser.getParam(params, "category")
	page = self.parser.getParam(params, "page")
	link = self.parser.getParam(params, "url")
	service = self.parser.getParam(params, "service")
	action = self.parser.getParam(params, "action")
	path = self.parser.getParam(params, "path")

	self.parser.debugParams(params, dbg)

    #MAIN MENU
	if name == None:
	    self.listsMainMenu(MENU_TAB)
    #LEKTOR
	elif category == self.setTable()[1]:
	    self.listsCategoriesMenu('lektor', MAINURL)
    #NAPISY
	elif category == self.setTable()[2]:
	    self.listsCategoriesMenu('napisy', MAINURL)
    #PREMIERY
	elif category == self.setTable()[3]:
	    self.listsCategoriesMenu('premiery', MAINURL)
    #NAJLEPSZE FILMY
	elif category == self.setTable()[4]:
	    self.listsMovies(TOP_LINK, 'top100')
    #GORĄCE TYTUŁY OSTATNICH 30 DNI
	elif category == self.setTable()[5]:
	    self.listsMovies(HOT_LINK, 'hot')
    #DATA WYDANIA
	elif category == self.setTable()[6]:
	    self.listsCategoriesMenu('data', MAINURL + 'filmy/rok')
    #WYSZUKAJ
	elif category == self.setTable()[7]:
	    text = self.gui.searchInput(SERVICE)
	    url = MAINURL + 'szukaj/' + text
	    self.searchTab(url)
    #HISTORIA WYSZUKIWANIA
	elif category == self.setTable()[8]:
	    t = self.history.loadHistoryFile(SERVICE)
	    self.listsHistory(t)

	if name == 'history':
            url = MAINURL + 'szukaj/' + title
	    self.searchTab(url)
    #LISTA TYTULOW
	if name == 'nextpage' or  name == 'submenu':
	    self.listsMovies(page, 'regular')
    #ODTWÓRZ VIDEO
	if name == 'playSelectedVideo':
	    linkVideo = ''
	    player = True
	    ID = self.getVideoID(page)
	    if ID != '':
		if 'maxvideo.pl' in ID: player = maxvideo.Player()
		linkVideo = self.up.getVideoLink(ID)
		self.gui.LOAD_AND_PLAY_VIDEO(linkVideo, title, player)
    #POBIERZ
	if action == 'download' and link != '':
	    if link.startswith('http'):
		linkVideo = self.up.getVideoLink(self.getVideoID(link))
		if linkVideo != False:
		    self.cm.checkDir(os.path.join(dstpath, SERVICE))
		    dwnl = downloader.Downloader()
		    dwnl.getFile({ 'title': title, 'url': linkVideo, 'path': path })
