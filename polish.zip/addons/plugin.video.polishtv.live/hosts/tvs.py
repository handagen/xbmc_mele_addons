# -*- coding: utf-8 -*-
import cookielib, os, string, StringIO
import os, time, base64, logging, calendar
import urllib, urllib2, re, sys, math, htmlentitydefs
import xbmcgui, xbmc, xbmcaddon, xbmcplugin
import traceback

scriptID = 'plugin.video.polishtv.live'
scriptname = "Polish Live TV"
ptv = xbmcaddon.Addon(scriptID)

BASE_RESOURCE_PATH = os.path.join( ptv.getAddonInfo('path'), "../resources" )
sys.path.append( os.path.join( BASE_RESOURCE_PATH, "lib" ) )
LOGOURL = ptv.getAddonInfo('path') + os.path.sep + "images" + os.path.sep + "tvs.png"

import sdLog, sdSettings, sdParser, urlparser, sdCommon, sdNavigation, sdErrors, downloader

log = sdLog.pLog()

dstpath = ptv.getSetting('default_dstpath')
dbg = ptv.getSetting('default_debug')

SERVICE = 'tvs'
MAINURL = 'http://www.tvs.pl'
INFORMACJEURL = 'http://www.tvs.pl/silesiainformacje.html'

SERVICE_MENU_TABLE = {
	1: "Programy TVS",
#	2: "Archiwum",
	3: "Silesia Informacje",
}
  
class TVSilesia:
	def __init__(self):
		log.info('Loading ' + SERVICE)
		self.settings = sdSettings.TVSettings()
		self.parser = sdParser.Parser()
		self.up = urlparser.urlparser()
		self.cm = sdCommon.common()
		self.history = sdCommon.history()
		self.navigation = sdNavigation.VideoNav()
		self.chars = sdCommon.Chars()
		self.exception = sdErrors.Exception()

	def setTable(self):
		return SERVICE_MENU_TABLE
	
	def listsMainMenu(self, table):
		for num, val in table.items():
			self.addDir(SERVICE, 'main-menu', val, '', '', '', LOGOURL, True, False)
		xbmcplugin.endOfDirectory(int(sys.argv[1]))
		
	def listsShows(self, url):
		query_data = { 'url': url, 'use_host': False, 'use_cookie': False, 'use_post': False, 'return_data': True }
		try:
			data = self.cm.getURLRequestData(query_data)
		except Exception, exception:
			traceback.print_exc()
			self.exception.getError(str(exception))
		r = re.compile('<div class="middle_center_box">(.+?)</div><br style="clear: both;" />', re.DOTALL).findall(data)
		if len(r)>0:
			r2 = re.compile('<div class="movie_foto_ramka".+?<img src="(.+?)" />.+?<span>(.+?)</span>.+?<a href="(.+?)">Zobacz online</a>', re.DOTALL).findall(r[0])
			if len(r2)>0:
				for i in range(len(r2)):
					self.addDir(SERVICE, 'shows', r2[i][1], '', '', r2[i][2], r2[i][0], True, False)
				xbmcplugin.endOfDirectory(int(sys.argv[1]))
				
	def listsInfos(self, mUrl, url, category="Silesia Informacje"):
		query_data = { 'url': url, 'use_host': False, 'use_cookie': False, 'use_post': False, 'return_data': True }
		try:
			data = self.cm.getURLRequestData(query_data)
		except Exception, exception:
			traceback.print_exc()
			self.exception.getError(str(exception))
		naj = re.compile("<h1>Silesia Informacje - wydanie (.+?)</h1>.+?'image'.+?'(.+?)',", re.DOTALL).findall(data)
		if len(naj)>0:
			self.addDir(SERVICE, 'playSelectedMovie', category, category+" - "+naj[0][0], '', url, naj[0][1], True, False)
		r = re.compile('Ostatnie wydania</h2>(.+?)<a id="next1" href="#"></a>', re.DOTALL).findall(data)
		if len(r)>0:
			r2 = re.compile('<div class="boxgrid caption".+?<img src="(.+?)".+?<a .+?href="(.+?)".+?<span.+?>(.+?)</span>', re.DOTALL).findall(r[0])
			if len(r2)>0:
				for i in range(len(r2)):
					self.addDir(SERVICE, 'playSelectedMovie', category, category+" - "+r2[i][2], '', mUrl+'/'+r2[i][1], r2[i][0], True, False)
				xbmcplugin.endOfDirectory(int(sys.argv[1]))
				
	def listsShowsEpisodes(self, url, category):
		query_data = { 'url': url, 'use_host': False, 'use_cookie': False, 'use_post': False, 'return_data': True }
		try:
			data = self.cm.getURLRequestData(query_data)
		except Exception, exception:
			traceback.print_exc()
			self.exception.getError(str(exception))
		r = re.compile('<div class="bottom_box">(.+?)<div style="clear: both;"></div>', re.DOTALL).findall(data)
		if len(r)>0:
			r2 = re.compile('<div class="movie_foto_ramka".+?<img src="(.+?)" />.+?;">(.+?)</span></span>.+?<a href="(.+?)">Zobacz online</a>', re.DOTALL).findall(r[0])
			if len(r2)>0:
				for i in range(len(r2)):
					self.addDir(SERVICE, 'playSelectedMovie', category, category+" - "+r2[i][1], '', r2[i][2], r2[i][0], True, False)
				xbmcplugin.endOfDirectory(int(sys.argv[1]))
			else:
				d = xbmcgui.Dialog()
				d.ok('Brak hostingu', SERVICE + ' - nie dodano jeszcze tego wideo.', 'Zapraszamy w innym terminie.')
	
	def setLinkTable(self, url, host):
		strTab = []
		strTab.append(url)
		strTab.append(host)
		return strTab

	
	def getItemTitles(self, table):
		out = []
		for i in range(len(table)):
			value = table[i]
			out.append(value[1])
		return out
	
	def getHostingTable(self,url):
		valTab = []
		query_data = { 'url': url, 'use_host': False, 'use_cookie': False, 'use_post': False, 'return_data': True }
		try:
			data = self.cm.getURLRequestData(query_data)
		except Exception, exception:
			traceback.print_exc()
			self.exception.getError(str(exception))
		playlistfile = re.compile("'playlistfile'.+?'(.+?)',", re.DOTALL).findall(data)
		filename = re.compile("'file'.+?'(.+?)',", re.DOTALL).findall(data)
		streamer = re.compile("'streamer'.+?'(.+?)',", re.DOTALL).findall(data)
		if len(filename) > 0 and len(streamer) > 0:
			return streamer[0].replace("rtmpt://","rtmp://").replace(":1935",":80")+" playpath=mp4:"+filename[0]+" swfUrl=http://www.tvs.pl/gfx/mediaplayer-5.3-licensed/player.swf live=true swfVfy=true"
		elif len(playlistfile) > 0:
			query_data = { 'url': playlistfile[0], 'use_host': False, 'use_cookie': False, 'use_post': False, 'return_data': True }
			try:
				data = self.cm.getURLRequestData(query_data)
			except Exception, exception:
				traceback.print_exc()
				self.exception.getError(str(exception))
			filename = re.compile("<jwplayer:file>(.+?)</jwplayer:file>", re.DOTALL).findall(data)
			streamer = re.compile("<jwplayer:streamer>(.+?)</jwplayer:streamer>", re.DOTALL).findall(data)
			if len(filename) > 1:
				for i in range(len(filename)):
					linkVideos = streamer[i].replace("rtmpt://","rtmp://").replace(":1935",":80")+" playpath=mp4:"+filename[i]+" swfUrl=http://www.tvs.pl/gfx/mediaplayer-5.3-licensed/player.swf live=true swfVfy=true"
					valTab.append(self.setLinkTable(linkVideos, 'Część '+str(i+1)))
				valTab.sort(key = lambda x: x[0])
				d = xbmcgui.Dialog()
				item = d.select("Wybór części", self.getItemTitles(valTab))
				print str(item)
				if item != -1:
					linkVideo = valTab[item][0]
					return linkVideo
			elif len(filename) == 1:
				return streamer[0].replace("rtmpt://","rtmp://").replace(":1935",":80")+" playpath=mp4:"+filename[0]+" swfUrl=http://www.tvs.pl/gfx/mediaplayer-5.3-licensed/player.swf live=true swfVfy=true"
			else:
				d = xbmcgui.Dialog()
				d.ok('Brak hostingu', SERVICE + ' - nie dodano jeszcze tego wideo.', 'Zapraszamy w innym terminie.')
		else:
			d = xbmcgui.Dialog()
			d.ok('Brak hostingu', SERVICE + ' - nie dodano jeszcze tego wideo.', 'Zapraszamy w innym terminie.')

	def addDir(self, service, name, category, title, plot, page, iconimage, folder = True, isPlayable = True):
		u=sys.argv[0] + "?service=" + service + "&name=" + name + "&category=" + category + "&title=" + title + "&page=" + urllib.quote_plus(page)
		if name == 'main-menu' or name == 'shows' or name == 'genset':
			title = category
		if iconimage == '':
			iconimage = "DefaultVideo.png"
		liz=xbmcgui.ListItem(title, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
		if isPlayable:
			liz.setProperty("IsPlayable", "true")
		liz.setInfo( type="Video", infoLabels={ "Title": title, "Plot": plot } )
		if dstpath != "None" or not dstpath and name == 'playSelectedMovie':
			if dbg == 'true':
				log.info(SERVICE + ' - addDir() -> title: ' + title)
				log.info(SERVICE + ' - addDir() -> url: ' + page)
				log.info(SERVICE + ' - addDir() -> dstpath: ' + os.path.join(dstpath, SERVICE))
			cm = self.navigation.addVideoContextMenuItems({ 'service': SERVICE, 'title': urllib.quote_plus(self.chars.replaceChars(title)), 'url': urllib.quote_plus(page), 'path': os.path.join(dstpath, SERVICE) })
			liz.addContextMenuItems(cm, replaceItems=False)
			xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=folder)

	def handleService(self):
		params = self.parser.getParams()
		name = self.parser.getParam(params, "name")
		title = self.parser.getParam(params, "title")
		category = self.parser.getParam(params, "category")
		page = self.parser.getParam(params, "page")
		icon = self.parser.getParam(params, "icon")
		link = self.parser.getParam(params, "url")
		vtitle = self.parser.getParam(params, "vtitle")
		service = self.parser.getParam(params, "service")
		action = self.parser.getParam(params, "action")
		path = self.parser.getParam(params, "path")

		if dbg == 'true':
			log.info ('name: ' + str(name))
			log.info ('title: ' + str(title))
			log.info ('category: ' + str(category))
			log.info ('page: ' + str(page))

		if str(page)=='None' or page=='': page = 0
	#MAIN MENU
		if name == None:
			self.listsMainMenu(SERVICE_MENU_TABLE)

	#PROGRAMY TVS
		if category == self.setTable()[1]:
			self.listsShows(MAINURL+'/tv/programy/')
			
	#ARCHIWUM - wylaczone 
	#	if category == self.setTable()[2]:
	#		self.listsShows(MAINURL+'/tv/archiwum/')
		
		if name == 'shows':
			self.listsShowsEpisodes(str(page).replace('program,','archiwum,'), str(category))

	#SILESIA INFORMACJE
		if category == self.setTable()[3]:
			self.listsInfos(MAINURL, MAINURL+'/silesiainformacje.html', str(category))
	
	#Wybrano odcinek z tv 
		if name == 'playSelectedMovie':
			linkVideo = self.getHostingTable(str(page))
			log.info("fdgf "+linkVideo)
			if linkVideo != False:
				self.cm.LOAD_AND_PLAY_VIDEO(linkVideo, title)
			else:
				d = xbmcgui.Dialog()
				d.ok('Brak linku', SERVICE + ' - przepraszamy, chwilowa awaria.', 'Zapraszamy w innym terminie.')
		
		if service == SERVICE and action == 'download' and link != '':
			self.cm.checkDir(os.path.join(dstpath, SERVICE))
			if dbg == 'true':
				log.info(SERVICE + ' - handleService()[download][0] -> title: ' + urllib.unquote_plus(vtitle))
				log.info(SERVICE + ' - handleService()[download][0] -> url: ' + urllib.unquote_plus(link))
				log.info(SERVICE + ' - handleService()[download][0] -> path: ' + path)
			if urllib.unquote_plus(link).startswith('http://'):
				linkVideo = self.getHostingTable(urllib.unquote_plus(link))
				if dbg == 'true':
					log.info(SERVICE + ' - handleService()[download][2] -> title: ' + urllib.unquote_plus(vtitle))
					log.info(SERVICE + ' - handleService()[download][2] -> url: ' + linkVideo)						
				if linkVideo != False:
					if dbg == 'true':
						log.info(SERVICE + ' - handleService()[download][3] -> title: ' + urllib.unquote_plus(vtitle))
						log.info(SERVICE + ' - handleService()[download][3] -> url: ' + linkVideo)
						log.info(SERVICE + ' - handleService()[download][3] -> path: ' + path)						
					dwnl = downloader.Downloader()
					dwnl.getFile({ 'title': urllib.unquote_plus(vtitle), 'url': linkVideo, 'path': path })
