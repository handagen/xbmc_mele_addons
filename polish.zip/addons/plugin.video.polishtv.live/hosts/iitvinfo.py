# -*- coding: utf-8 -*-
import os, string, StringIO
import urllib, urllib2, re, sys
import xbmcaddon, traceback, xbmcgui

#todo: Wyszukiwanie i przeglądanie po polskich nazwach
#fixme: Przebudowanie systemu odtwarzania

scriptID = sys.modules[ "__main__" ].scriptID
scriptname = sys.modules[ "__main__" ].scriptname
ptv = xbmcaddon.Addon(scriptID)

SERVICE = 'iitvinfo'
COOKIEFILE = ptv.getAddonInfo('path') + os.path.sep + "cookies" + os.path.sep + "iitv.cookie"
BASE_RESOURCE_PATH = os.path.join( ptv.getAddonInfo('path'), "../resources" )
sys.path.append( os.path.join( BASE_RESOURCE_PATH, "lib" ) )
LOGOURL = os.path.join(ptv.getAddonInfo('path'), "images/") + SERVICE + '.png'

import sdLog, sdSettings, sdParser, urlparser, sdCommon, sdNavigation, sdErrors, downloader, sdMeta

log = sdLog.pLog()

dbg = sys.modules[ "__main__" ].dbg
dstpath = ptv.getSetting('default_dstpath')

mainUrl = 'http://iitv.info'
mainUrlPr = 'http://premium.iitv.info'
logUrl = mainUrlPr + '/logowanie.html' 
imgUrl = 'http://static.iitv.info/static/serials/'
ajaxUrl = mainUrl + '/ajax_player.html?code='
postUrl = mainUrlPr + '/getVideo.html'
favUrlPr = mainUrlPr + '/ulubione_seriale,ulubione.html'

login = ptv.getSetting('iiTVinfo_login')
password = ptv.getSetting('iiTVinfo_password')

if login == '' or password == '':
	MENU_TAB = {
		1: "Seriale alfabetycznie",
		2: "Ostatnio uzupełnione seriale",
		3: "",
		4: "Wyszukaj",
		5: "Historia Wyszukiwania"
	}
else:
	MENU_TAB = {
		1: "Seriale alfabetycznie",
		2: "Ostatnio uzupełnione seriale",
		3: "Ulubione seriale",
		4: "Wyszukaj",
		5: "Historia Wyszukiwania"
	}

class iiTVInfo:
	def __init__(self):
		log.info('Loading ' + SERVICE)
		self.settings = sdSettings.TVSettings()
		self.parser = sdParser.Parser()
		self.up = urlparser.urlparser()
		self.cm = sdCommon.common()
		self.exception = sdErrors.Exception()
		self.history = sdCommon.history()
		self.gui = sdNavigation.sdGUI()
		self.meta = sdMeta.sdMeta()

	def setTable(self):
		return MENU_TAB

	def getImage(self,url):
		imageLink=imgUrl + url[1:-1] + '_vertical.jpg'
		return imageLink

	def listsMainMenu(self, table):
		for num, val in table.items():
			params = {'service': SERVICE, 'name': 'main-menu','category': val, 'title': val, 'icon': LOGOURL}
			self.gui.addDir(params)
		self.gui.endDir()

	def listsABCMenu(self, table):
		for i in range(len(table)):
			params = {'service': SERVICE, 'name': 'abc-menu','category': table[i], 'title': table[i], 'icon': LOGOURL}
			self.gui.addDir(params)
		self.gui.endDir()

	def getLastParts(self, url):
		strTab = []
		valTab = []
		query_data = { 'url': url, 'use_host': False, 'use_cookie': False, 'use_post': False, 'return_data': True }
		try:
			data = self.cm.getURLRequestData(query_data)
		except Exception, exception:
			traceback.print_exc()
			self.exception.getError(str(exception))
			exit()
		match = re.compile('<h2>Ostatnio uzupełnione seriale(.+?)<div id="latest_page">', re.DOTALL).findall(data)
		if len(match) > 0:
			match2 = re.compile('<div class="latest_title"><a href=".+?">\n(.+?)</a></div>\n.+?<div class="latest_info">\n.+?<a href="(.+?)"><span>(.+?)</span>(.+?)<').findall(match[0])
			if len(match2) > 0:
				for i in range(len(match2)):
					show = match2[i][0].strip().split('<br>')
					if int(len(show)) == 2:
						show = self.cm.html_entity_decode(show[1].replace('<span>','').replace('</span>',''))
						showPl = self.cm.html_entity_decode(show[0].replace('<span>','').replace('</span>',''))
					else:
						show = showPl = self.cm.html_entity_decode(show[0].replace('<span>','').replace('</span>',''))

					seasonEpisode = match2[i][2].strip().replace('s','').split('e')
					season = seasonEpisode[0]
					episode = seasonEpisode[1]
					episodeName = self.cm.html_entity_decode(match2[i][3].strip())

					page = '/' + match2[i][1]

					s = match2[i][1].split('/')
					img = imgUrl + s[0] + '.jpg'

					strTab.append(show)			#0
					strTab.append(showPl)		#1
					strTab.append(season)		#2
					strTab.append(episode)		#3
					strTab.append(episodeName)	#4
					strTab.append(page)			#5
					strTab.append(img)			#6
					valTab.append(strTab)		#7
					strTab = []
		return valTab

	def showLastParts(self, url):
		LastParts = self.getLastParts(url)
		if len(LastParts) > 0:
			pDialog = self.gui.percentDialog()
			pDialog.create('SD-XBMC ' + SERVICE, 'Ładowanie informacji ostatnio dodanych serialach...')
			for i in range(len(LastParts)):
				if pDialog.iscanceled(): break
				pDialog.update(int(i * 100.0 / len(LastParts)), 'Ładowanie informacji ostatnio dodanych serialach...', LastParts[i][1]+' S'+LastParts[i][2]+'E'+LastParts[i][3])
				meta = self.meta.getSingleEpisodeMeta(LastParts[i][0], LastParts[i][2], LastParts[i][3])
				title = LastParts[i][1] + ' - ' + LastParts[i][4]

				params = {'service': SERVICE, 'dstpath': dstpath, 'tvshowtitle': LastParts[i][1], 'season': int(LastParts[i][2]), 'episode': int(LastParts[i][3]), 'title': title, 'page': LastParts[i][5], 'icon': LastParts[i][6]}
				params.update(meta)
				self.gui.playVideo(params)
		self.gui.endDir(False, 'episodes', 'MediaInfo3')

	def getListsSerial(self, letter):
		query_data = { 'url': mainUrl, 'use_host': False, 'use_cookie': False, 'use_post': False, 'return_data': True }
		try:
			data = self.cm.getURLRequestData(query_data)
		except Exception, exception:
			traceback.print_exc()
			self.exception.getError(str(exception))
			exit()
		match = re.compile('<li class="serial_menu.+?><a href="(.+?)">(.+?)</a>').findall(data)
		valTab = []
		if len(match) > 0:
			for i in range(len(match)):
				if not '<b>' in match[i][1]:
					addItem = False
					if letter == '0 - 9' and (ord(match[i][1][0]) < 65 or ord(match[i][1][0]) > 91): addItem = True
					if (letter == match[i][1][0].upper()): addItem = True
					if (addItem):
						valTab.append(match[i])
		return valTab

	def getListsSearch(self, text):
		query_data = { 'url': mainUrl, 'use_host': False, 'use_cookie': False, 'use_post': False, 'return_data': True }
		try:
			data = self.cm.getURLRequestData(query_data)
		except Exception, exception:
			traceback.print_exc()
			self.exception.getError(str(exception))
			exit()
		match = re.compile('<li class="serial_menu.+?><a href="(.+?)">(.+?)</a>').findall(data)
		valTab = []
		#match = re.compile('<li class="serial_menu.+?" style="display:.+?"><a href="(.+?)">(.+?)</a>').findall(data)
		if len(match) > 0:
			for i in range(len(match)):
				if text.lower() in match[i][1].lower():
					valTab.append(match[i])
		return valTab

	def listsSerial(self, show):
		if len(show) > 0:
			pDialog = self.gui.percentDialog()
			pDialog.create('SD-XBMC ' + SERVICE, 'Ładowanie informacji o serialu...')
			for i in range(len(show)):
				if pDialog.iscanceled(): break
				image = self.getImage(show[i][0])
				item = self.meta.getShowMeta(show[i][1])
				pDialog.update(int(i * 100.0 / len(show)), 'Ładowanie informacji o serialu...', show[i][1])
				params = {'service': SERVICE, 'name': 'serial-season', 'tvshowtitle': show[i][1], 'title': show[i][1], 'page': show[i][0], 'icon': image}
				params.update(item)
				self.gui.addDir(params)
		self.gui.endDir(True, "tvshows", 'MediaInfo3')

	def getSeason(self, url, serial):
		query_data = { 'url': mainUrl + url, 'use_host': False, 'use_cookie': False, 'use_post': False, 'return_data': True }
		try:
			data = self.cm.getURLRequestData(query_data)
		except Exception, exception:
			traceback.print_exc()
			self.exception.getError(str(exception))
			exit()
		match = re.compile('<div class="serial_season">Sezon (.+?)</div>').findall(data)
		valTab = []
		if len(match) > 0:
			img = self.getImage(url)
			for i in range(len(match)):
				valTab.append(match[i])
		return valTab

	def showSeason(self, url, serial, tvdbid):
		seasons = self.getSeason(url, serial)
		if len(seasons) > 0:
			pDialog = self.gui.percentDialog()
			pDialog.create('SD-XBMC ' + SERVICE, 'Ładowanie informacji o sezonie...')
			image = self.getImage(url)
			for i in range(len(seasons)):
				if pDialog.iscanceled(): break
				item = self.meta.getSeasonMeta(tvdbid, int(seasons[i]))
				pDialog.update(int(i * 100.0 / len(seasons)), 'Ładowanie informacji o sezonie...', 'Sezon '+seasons[i])
				params = {'service': SERVICE, 'name': 'serial-episode', 'tvshowtitle': serial, 'season': int(seasons[i]), 'title': 'Sezon '+seasons[i], 'page': url, 'icon': image}
				params.update(item)
				params.update({'count': tvdbid})
				self.gui.addDir(params)
		self.gui.endDir(True, "tvshows")

	def getEpisode(self, url, serial, sezon):
		query_data = { 'url': mainUrl + url, 'use_host': False, 'use_cookie': False, 'use_post': False, 'return_data': True }
		try:
			data = self.cm.getURLRequestData(query_data)
		except Exception, exception:
			traceback.print_exc()
			self.exception.getError(str(exception))
			exit()
		match = re.compile('<div class="serial_season">Sezon '+sezon+'</div>.+?(?:<div class="serial_season">|</section>)', re.DOTALL).findall(data)
		if len(match) > 0:
			match_parts = re.compile('<a  href="(.+?)"><span class="release">(.+?)</span>(.+?)</a>').findall(match[0])
			if len(match_parts) > 0:
				return match_parts
		return []

	def showEpisode(self, url, serial, sezon, tvdbid):
		episodelist = self.meta.getEpisodesList(tvdbid, int(sezon))
		match = self.getEpisode(url, serial, sezon)
		if len(match) > 0:
			img = self.getImage(url)
			for i in range(len(match)):
				pTab = match[i][1].split('e')
				if (len(pTab)==2):
					episode = pTab[1]
					title = '%s S%sE%s - %s' % (serial, sezon, episode, self.cm.html_entity_decode(match[i][2]))
					link = match[i][0]
					meta = self.meta.getEpisodeMeta(episodelist, episode)
					params = {'service': SERVICE, 'dstpath': dstpath, 'tvshowtitle': serial, 'season': int(sezon), 'episode': int(episode), 'title': title, 'page': link, 'icon': img}
					params.update(meta)
					self.gui.playVideo(params)
		self.gui.endDir(False, 'episodes', 'MediaInfo3')

	def showFavSerial(self):
		strTab = []
		valTab = []
		query_data = { 'url': favUrlPr, 'use_host': False, 'use_cookie': True, 'save_cookie': False, 'load_cookie': True, 'cookiefile': COOKIEFILE, 'use_post': False, 'return_data': True }
		try:
			data = self.cm.getURLRequestData(query_data)
		except Exception, exception:
			traceback.print_exc()
			self.exception.getError(str(exception))
			exit()
		match = re.compile('<h2><a title="(.+?)" href="serial,(.+?).html">').findall(data)
		if len(match) > 0:
			for i in range(len(match)):
				strTab.append('/' + match[i][1] + '/')
				strTab.append(match[i][0])
				valTab.append(strTab)
				strTab = []
		return valTab

	def getVideoID(self, data):
		strTab = []
		valTab = []
		videoW = ''
		match = re.compile('<li><a href="#tabs-(.+?)" class=".+?">(.+?)</a></li>').findall(data)
		if len(match) > 0:
			for i in range(len(match)):
				strTab.append(match[i][0])
				strTab.append(match[i][1])
				valTab.append(strTab)
				strTab = []
			valTab.sort(key = lambda x: x[0])
			d = xbmcgui.Dialog()
			item = d.select("Wybierz wersję", self.cm.getItemTitles(valTab))
			if item != -1:
				videoW = str(valTab[item][0])
				log.info('W-ID: ' + videoW)
			return videoW
		else:
			return False

	def extractHost(self, code):
		query_data = { 'url': ajaxUrl + code, 'use_host': False, 'use_cookie': False, 'use_post': False, 'return_data': True }
		try:
			data = self.cm.getURLRequestData(query_data)
		except Exception, exception:
			traceback.print_exc()
			self.exception.getError(str(exception))
			exit()
		data = data.replace('\\','')

		#target=\"_blank\" href=\"http:\/\/streamo.tv\/watch,7,T9ohwodW.html<\/a>
		#target=\"_blank\" href=\"http:\/\/hd3d.cc\/file,watch,08D99C5E17CDB0BD.html\">http:\/\/hd3d.cc\/file,watch,08D99C5E17CDB0BD.html<\/a>
		match = re.compile('target="_blank" href="(.+?)["<]', re.DOTALL).findall(data)

		if len(match)>0:
			return match[0]
		return False
				

	def getPlayTable(self,url):
		strTab = []
		valTab = []
		videoH = ''
		query_data = { 'url': url, 'use_host': False, 'use_cookie': False, 'use_post': False, 'return_data': True }
		try:
			data = self.cm.getURLRequestData(query_data)
		except Exception, exception:
			traceback.print_exc()
			self.exception.getError(str(exception))
			exit()
		w = self.getVideoID(data)
		r = re.compile('<div id="tabs-' + w + '".+?>(.+?)</ul>', re.DOTALL).findall(data)

		if len(r)>0:
		#<li class="player_li"><a class="player_lk" data-link_id="373780_4" href="?player=373780"><img class="sprite-favicon_sprocked-com" src="http://static.iitv.info/static/img/blank.gif" alt="sprocked.com">sprocked.com</a><span class="quality_rate quality_unknown" title="Brak wystarczaj\xc4\x85cej liczby ocen"></span></li>
		#r2 = re.compile('href="(.+?)" data.+?><img src=".+?" alt="(.+?)"').findall(r[0])
			r2 = re.compile('data-link_id="(.+?)" href=".+?"><img class=".+?" src=".+?" alt=".+?">(.+?)</a>').findall(r[0])
			if len(r2)>0:
				for i in range(len(r2)):
					if not '.' in r2[i][1]:
						title = r2[i][1]
						href = r2[i][0]
					else:
						title = self.up.getHostName('http://' + r2[i][1] + '/', True)
						href = r2[i][0]
					strTab.append(href)
					strTab.append(str(i+1) + '. ' + title)
					valTab.append(strTab)
					strTab = []
				d = xbmcgui.Dialog()
				item = d.select("Wybierz hosting", self.cm.getItemTitles(valTab))
				if item != -1:
					videoH = str(valTab[item][0])
					log.info('H-ID: ' + videoH)
				return videoH
			else:
				return False
		else:
			return False

	def getIM(self, url):
		query_data = { 'url': url, 'use_host': False, 'use_cookie': False, 'use_post': False, 'return_data': True }
		match = re.compile('<input type="hidden" id="hid_im" value="(.+?)" />').findall(self.cm.getURLRequestData(query_data))
		if len(match) > 0:
			IM = match[0]
			log.info ('IM :' + IM)
			return IM
		else:
			return False

	def getPostTab(self, url):
		strTab = []
		valTab = []

		L = self.getPlayTable(url)

		if 'streamo' in L:
			em = 'streamo'
			im = self.getIM(url)
		elif 'nonlimit' in L:
			em = 'nonlimit'
			im = self.getIM(url)
		elif 'scs' in L:
			em = 'scs'
			im = self.getIM(url)
		else:
			em = ''
			im = ''
		query_data = { 'url': url + L, 'use_host': False, 'use_cookie': False, 'use_post': False, 'return_data': True }
		try:
			data = self.cm.getURLRequestData(query_data)
		except Exception, exception:
			traceback.print_exc()
			self.exception.getError(str(exception))
			exit()
		match = re.compile('class="play.+?" data-em="" data-tk="(.+?)" id="(.+?)"></div>').findall(data)
		if len(match) > 0:
			for i in range(len(match)):
				value = match[i]
				strTab.append(value[0])
				strTab.append(value[1])
				strTab.append(em)
				strTab.append(im)
				valTab.append(strTab)
				strTab = []
		return valTab

	def getPost(self, url):
		VideoID = ''
		table = self.getPostTab(url)
		for i in range(len(table)):
			value = table[i]
			code = value[1]
			tk = value [0]
			em = value [2]
			im = value [3]
			log.info('code: ' + code)
			log.info('tk: ' + tk)
			log.info('em: ' + em)
			log.info('im: ' + im)
		url = mainUrl + "/views/player_ajax.php?code=" + code + "&tk=" + tk + "&em=" + em + '&im=' + im
		query_data = { 'url': url, 'use_host': False, 'use_cookie': False, 'use_post': False, 'return_data': True }
		try:
				data = self.cm.getURLRequestData(query_data)
		except Exception, exception:
				traceback.print_exc()
				self.exception.getError(str(exception))
				exit()
		link = data.replace('\\', '').replace('movie/embed', 'movie/show').replace('</a></div></div>', '')
		match = re.compile('http:(.+?)\"').findall(link)
		if len(match) > 0:
			for i in range(len(match)):
				VideoID = 'http:' + match[0]
				log.info('V-ID: ' + VideoID)
			return VideoID
		else:
			return False

	def listsHistory(self, table):
		for i in range(len(table)):
			if table[i] <> '':
				params = {'service': SERVICE, 'name': 'history', 'title': table[i],'icon': LOGOURL}
				self.gui.addDir(params)
		self.gui.endDir()


	def getVideoIDPr(self, data):
		strTab = []
		valTab = []
		videoW = ''
		match = re.compile('<li id="(.+?)".+?\n.+?href=""><img src=".+?" ?> (.+?)</a>').findall(data)
		if len(match) > 0:
			for i in range(len(match)):
				strTab.append(match[i][0])
				strTab.append(match[i][1].capitalize())
				valTab.append(strTab)
				strTab = []
			valTab.sort(key = lambda x: x[0])
			d = xbmcgui.Dialog()
			item = d.select("Wybierz wersję", self.cm.getItemTitles(valTab))
			if item != -1:
				videoW = str(valTab[item][0])
				log.info('W-ID: ' + videoW)
			return videoW
		else:
			return False
		
	def getPlayTablePr(self,url):
		strTab = []
		valTab = []
		videoH = ''
		query_data = { 'url': url, 'use_host': False, 'use_cookie': True, 'save_cookie': False, 'load_cookie': True, 'cookiefile': COOKIEFILE, 'use_post': False, 'return_data': True }
		try:
				data = self.cm.getURLRequestData(query_data)
		except Exception, exception:
				traceback.print_exc()
				self.exception.getError(str(exception))
				exit()
		w = self.getVideoIDPr(data)
		
		#jesli 'w' jest False, to nie jestes poprawnie zalogowany
		if w != False:
			match = re.compile('hash="(.+?)" class="' + w + '".+?<a class="switcher.+?favicon_(.+?)-.+?"').findall(data)
			if len(match) > 0:
				for i in range(len(match)):
					strTab.append(match[i][0])
					strTab.append(str(i+1) + '. ' + match[i][1])
					valTab.append(strTab)
					strTab = []
				d = xbmcgui.Dialog()
				item = d.select("Wybierz hosting", self.cm.getItemTitles(valTab))
				test = str(valTab[item][1])
				if item != -1:
					videoH = str(valTab[item][0])
					log.info('H-ID (premium): ' + videoH)
					return videoH
				else:
					return False
			else:
				return False
		return False

	def getPostPr(self, url):
		VideoID = ''
		h = self.getPlayTablePr(url)
		if h == False:
			return False
		query_data = { 'url': postUrl, 'use_host': False, 'use_cookie': True, 'save_cookie': False, 'load_cookie': True, 'cookiefile': COOKIEFILE, 'use_post': True, 'return_data': True }
		values = { 'hash': h }
		try:
				data = self.cm.getURLRequestData(query_data, values)
		except Exception, exception:
				traceback.print_exc()
				self.exception.getError(str(exception))
				exit()
		match = re.compile("clip: {\n.+?url: '(.+?)'").findall(data)

		if len(match) > 0:
			for i in range(len(match)):
				#VideoID = 'http' + match[i]
				log.info('V-IDPr: ' + match[i])
			return match[i]
		else:
			return False

	def nUrl(self, url):
		tUrl = re.findall('/(.+?)/(.+?)-(.+?).html',url)
		if len(tUrl) != 0:
			nUrl = mainUrlPr + '/odcinek,' + tUrl[0][0] + ',' + tUrl[0][2] + ',' + tUrl[0][1] + '.html'
			return nUrl
		else:
			tUrl = re.findall('/(.+?)/(.+?)-.html',url)
			nUrl = mainUrlPr + '/odcinek,' + tUrl[0][0] + ',' + tUrl[0][1] + '.html'
			return nUrl
		
	def handleService(self):
		params = self.parser.getParams()
		name = self.parser.getParam(params, "name")
		title = self.parser.getParam(params, "title")
		category = self.parser.getParam(params, "category")
		page = self.parser.getParam(params, "page")
		link = self.parser.getParam(params, "url")
		icon = self.parser.getParam(params, "icon")
		service = self.parser.getParam(params, "service")
		action = self.parser.getParam(params, "action")
		path = self.parser.getParam(params, "path")
		sezon = self.parser.getParam(params, "season")
		epizod = self.parser.getParam(params, "episode")
		serial = self.parser.getParam(params, "tvshowtitle")
		tvdbid = self.parser.getParam(params, "count")

		self.parser.debugParams(params, dbg)

	#MAIN MENU + LOGOWANIE
		if name == None:
			if login == '' or password == '': loginData = {}
			else: loginData = { 'email': login, 'password': password, "remember_me": "1" }
			self.cm.requestLoginData(logUrl, 'title="Konto premium ważne do:', COOKIEFILE, loginData)
			self.listsMainMenu(MENU_TAB)
			
	#SERIALE ALFABETYCZNIE
		if category == self.setTable()[1]:
			self.listsABCMenu(self.cm.makeABCList())
		if name == 'abc-menu':
			show = self.getListsSerial(category)
			self.listsSerial(show)
		elif name == 'serial-season':
			self.showSeason(page, serial, tvdbid)
		elif name == 'serial-episode':
			self.showEpisode(page, serial, sezon, tvdbid)
			
	#OSTATNIO UZUPEŁNIONE SERIALE
		if category == self.setTable()[2]:
			self.showLastParts(mainUrl)

	#ULUBIONE SERIALE
		if category == self.setTable()[3]:
			show = self.showFavSerial()
			self.listsSerial(show)
			
	#WYSZUKAJ
		if category == self.setTable()[4]:
			text = self.gui.searchInput(SERVICE)
			show = self.getListsSearch(text)
			self.listsSerial(show)
			
	#HISTORIA WYSZUKIWANIA
		if category == self.setTable()[5]:
			t = self.history.loadHistoryFile(SERVICE)
			self.listsHistory(t)

		if name == 'history':
			show = self.getListsSearch(title)
			self.listsSerial(show)
			
	#ODTWÓRZ VIDEO
		if name == 'playSelectedVideo':
			linkVideo = False
			if login != '' and password != '':
				linkVideo = self.getPostPr(self.nUrl(page))
			else:
				linkVideo = False
			if linkVideo == False:
				nUrl = mainUrl + page
				linkVideo = ''
				code = self.getPlayTable(nUrl)
				ID = self.extractHost(code)
				if (ID != False):
					linkVideo = self.up.getVideoLink(ID)
				else:
					d = xbmcgui.Dialog()
					d.ok(SERVICE + ' - przepraszamy', 'Ten materiał nie został jeszcze dodany', 'Zapraszamy w innym terminie.')
					return False
			self.gui.LOAD_AND_PLAY_VIDEO(linkVideo, title)
			
	#POBIERZ
		if action == 'download' and link != '':
			linkVideo = False
			if link.startswith('/'):
				if login != '' and password != '':
					linkVideo = self.getPostPr(self.nUrl(link))
				else:
					linkVideo = False
				if linkVideo == False:
					nUrl = mainUrl + link
					linkVideo = ''
					code = self.getPlayTable(nUrl)
					ID = self.extractHost(code)
					if (ID != False):
						linkVideo = self.up.getVideoLink(ID)
					else:
						d = xbmcgui.Dialog()
						d.ok(SERVICE + ' - przepraszamy', 'Ten materiał nie został jeszcze dodany', 'Zapraszamy w innym terminie.')
						return False
				if linkVideo != False:
					self.cm.checkDir(os.path.join(dstpath, SERVICE))
					dwnl = downloader.Downloader()
					dwnl.getFile({ 'title': title, 'url': linkVideo, 'path': path })
