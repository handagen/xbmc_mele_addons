Welcome to Navi-X v3.0 Plugin

Changelog:

-Added browsing history list. The list can be cleared
from the context menu.

-Create shortcuts to Navi-X playlists in your script folder.
Select the playlist and use the "Create playlist shortcut" option
in the context menu.

-Faster processing of large playlists. Large playlist are automatically 
divided into pages of 200 entries each.

-Reworked the downloader for improved stability.

-Parental control: Hide blocked playlists. This option can be switched on and off
from the "Blocked Content" playlist using the context menu.

------------------

Navi-X is tested using the T3CH build. If you are having problems
and are using a different XBMC then please let me know. Thanks.

Questions, suggestions, help, playlists to rodejo16@gmail.com