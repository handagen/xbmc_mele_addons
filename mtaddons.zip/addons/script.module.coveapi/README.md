The COVE API:
- is a JSON-based, web API.
- is a read-only service that provides access to full episodes, clips, and promotions.  
- is a service that allows you to create applications that use PBS video meta-data.  
- allows you to create applications that stream PBS videos. 
