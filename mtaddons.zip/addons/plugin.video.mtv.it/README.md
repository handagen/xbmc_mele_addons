plugin.video.mtv.it
==================

Kodi plugin for MTV.it on demand (tested on Kodi 14.0 Helix)

You may need to download the dependencies of this addon:
- script.module.neverwise 1.0.4 (https://github.com/NeverWise/script.module.neverwise/archive/master.zip)
- script.module.beautifulsoup 3.2.1 (http://mirrors.xbmc.org/addons/frodo/script.module.beautifulsoup/script.module.beautifulsoup-3.2.1.zip)
- script.module.parsedom 2.5.2 (http://mirrors.xbmc.org/addons/frodo/script.module.parsedom/script.module.parsedom-2.5.2.zip)
