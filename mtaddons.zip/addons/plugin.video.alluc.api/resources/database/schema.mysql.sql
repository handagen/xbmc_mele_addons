CREATE TABLE IF NOT EXISTS `favorites` (`id` INT NOT NULL AUTO_INCREMENT,`media` VARCHAR(10) NULL DEFAULT 'TV', `name` VARCHAR(125) NULL, `imdb_id` VARCHAR(15) NULL, `new` TINYINT NULL DEFAULT 0, PRIMARY KEY (`id`), UNIQUE INDEX `imdb_id_UNIQUE` (`imdb_id` ASC));

CREATE TABLE IF NOT EXISTS `search_cache` (`id` int(11) NOT NULL AUTO_INCREMENT, `hash_id` VARCHAR(125) NULL, `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP, `host` VARCHAR(125) NULL, `display` VARCHAR(225) NULL, `url` VARCHAR(255), PRIMARY KEY (`id`));

CREATE TABLE IF NOT EXISTS `player_state` (`id` int(11) NOT NULL AUTO_INCREMENT, `video_id` int(11) NULL, `media` VARCHAR(15) NULL, `current` VARCHAR(15) NULL, `total` VARCHAR(15) NULL, PRIMARY KEY (`id`), UNIQUE INDEX `video_id_UNIQUE` (`video_id`, `media` ASC));

CREATE TABLE IF NOT EXISTS `subscriptions` (`id` int(11) NOT NULL AUTO_INCREMENT, `imdb_id` VARCHAR(15) NULL, `title` VARCHAR(225) NULL, `enabled` TINYINT(1) DEFAULT 1, PRIMARY KEY (`id`), UNIQUE INDEX `imdb_id_UNIQUE` (`imdb_id` ASC));

CREATE TABLE IF NOT EXISTS `lists` (`id` int(11) NOT NULL AUTO_INCREMENT,`list` VARCHAR(125) NULL, `slug` VARCHAR(125) NULL, `media` VARCHAR(10) NULL, `sync` TINYINT(1) DEFAULT 1, PRIMARY KEY (`id`), UNIQUE INDEX `slug_UNIQUE` (`slug`, `media` ASC));

CREATE TABLE IF NOT EXISTS `list_movies`(`id` int(11) NOT NULL AUTO_INCREMENT,`list_id` int(11) NOT NULL, `imdb_id` VARCHAR(15) NULL, `path` VARCHAR(255) NULL, PRIMARY KEY (`id`));

CREATE TABLE IF NOT EXISTS `hosts` (`id` INT NOT NULL AUTO_INCREMENT, `host` VARCHAR(75) NULL, `title` VARCHAR(75) NULL, `enabled` TINYINT NULL DEFAULT 1, PRIMARY KEY (`id`), UNIQUE INDEX `host_UNIQUE` (`host` ASC));

CREATE TABLE IF NOT EXISTS `fetch_count` (`id` int(11) NOT NULL AUTO_INCREMENT, `num` int(11) DEFAULT NULL, `ts` date DEFAULT NULL, PRIMARY KEY (`id`), UNIQUE KEY `ts_UNIQUE` (`ts`));

CREATE OR REPLACE VIEW `cache_status` AS SELECT hash_id,  display, url, host, (((now() - ts) / 14400) < 4) AS fresh FROM search_cache;

