import urllib2, urllib, re
from urllib2 import URLError, HTTPError
from commonlib import *
try: 
	import simplejson as json
except ImportError: 
	import json
import xbmcaddon
from vfs import VFSClass
vfs = VFSClass()
COOKIE_PATH = vfs.join(DATA_PATH, 'cookies')
if not vfs.exists(COOKIE_PATH):
	vfs.mkdir(COOKIE_PATH)
COOKIE_JAR = vfs.join(COOKIE_PATH, 'imdb.lpw')
from BeautifulSoup import BeautifulSoup
class IMDB():
	def __init__(self):
		self.base_url = 'http://www.imdb.com/'	

	def get_genre_list(self, genre, media='movies', start=0):
		results = []
		from datetime import date
		year = date.today().year
		count = 25
		uri = 'search/title'
		params = {"genres": genre.lower(), "sort": "moviemeter,asc", "year": year, "count": count, "start": start}
		if media == 'movies':
			params['title_type'] = 'feature'
		else:
			params['title_type'] = 'tv_series'
		response = self._call(uri, params=params)
		soup = BeautifulSoup(response)
		elements = soup.findAll('td', {'class': 'image'})
		if start > 0:
			previous = start - count
			if previous < 0:
				previous = 0
			results.append({"title": '<< Previous Page', "display": '<< Previous Page', "year": "", "imdb_id": "", "poster": "", "fanart": "", "start": previous})
		if media=='movies':
			title = re.compile('^(.+?) \((\d{4})\)')
		else:
			title = re.compile('^(.+?) \((\d{4}) TV Series\)')
		for em in elements:
			a = em.find('a')
			href = a['href']
			imdb_id = re.search('/title/(tt\d+)/', href).group(1)
			temp = title.search(a['title'])	
			display = "%s (%s)" % (temp.group(1), temp.group(2))
			record = {"title": temp.group(1), "year": temp.group(2), "imdb_id": imdb_id, "display": display, "poster": "", "fanart": ""}
			results.append(record)
		results.append({"title": 'Next Page >>', "display": 'Next Page >>', "year": "", "imdb_id": "", "poster": "", "fanart": "", "start": start + count})
		return results


	def _call(self, uri, data=None, params=None, return_json=False):
		url = self.base_url + uri
		if params: url = url + '?' + urllib.urlencode(params)
		ADDON.log(url, LOGVERBOSE)
		req = urllib2.Request(url)
		opener = urllib2.build_opener()
		try: response = opener.open(req)
		except HTTPError as e:
			ADDON.log(url)
			error_msg = 'IMDB HTTP Error %s: %s' % ( e.code, e.reason)
			ADDON.show_error_dialog([error_msg])
			SystemFailure(error_msg)
		except URLError as e:
			ADDON.log(url)
			error_msg = 'IMDB URL Error %s: %s' % ( e.code, e.reason)
			ADDON.show_error_dialog([error_msg])
			SystemFailure(error_msg)
		else:
			if return_json:
				data = json.loads(response.read())
				return data
			else:
				return response.read()

