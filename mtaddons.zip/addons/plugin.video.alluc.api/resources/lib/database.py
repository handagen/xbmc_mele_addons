import sys
import re
import xbmc
import xbmcaddon
import os
from commonlib import *

IGNORE_UNIQUE_ERRORS = True
from vfs import VFSClass
class DatabaseClass:
	def __init__(self, quiet=False):
		self.quiet=quiet

	def commit(self):
		if self.db_type == 'sqlite':
			print "Commiting to %s" % self.db_file
		else:
			print "Commiting to %s on %s" % (self.dbname, self.host)
		self.DBH.commit()

	def disconnect(self):
		if self.db_type == 'sqlite':
			print "Disconnecting from %s" % self.db_file
			self.DBC.close()
		else:
			print "Disconnecting from %s on %s" % (self.dbname, self.host)
			self.DBC.close()

	def dict_factory(self, cursor, row):
		d = {}
		for idx, col in enumerate(cursor.description):
			d[col[0]] = row[idx]
		return d

	def query(self, SQL, data=None,force_double_array=False):
		if data:
			self.DBC.execute(SQL, data)
		else:
			self.DBC.execute(SQL)
		rows = self.DBC.fetchall()
		if(len(rows)==1 and not force_double_array):
			return rows[0]
		else:
			return rows

	def query_assoc(self, SQL, data=None, force_double_array=False):
		self.DBH.row_factory = self.dict_factory
		cur = self.DBH.cursor()
		if data:
			cur.execute(SQL, data)
		else:
			cur.execute(SQL)
		rows = cur.fetchall()
		cur.close()
		if(len(rows)==1 and not force_double_array):
			return rows[0]
		else:
			return rows
	def execute(self, SQL, data=[]):
		try:
			if data:
				self.DBC.execute(SQL, data)
			else:
				self.DBC.execute(SQL)
			try:
				self.lastrowid = self.DBC.lastrowid
			except:
				self.lastrowid = None
		except Exception, e:
			if IGNORE_UNIQUE_ERRORS and re.match('column (.)+ is not unique$', str(e)):				
				#return None
				print '****** SQL ERROR: %s' % e
	def _initialize(self):
		global ADDON
		vfs = VFSClass()
		schema = vfs.join(ROOT_PATH, 'resources/database/schema.%s.sql' % self.db_type)
		if os.path.exists(schema):
			sql_file = open(schema, 'r')
			sql_text = sql_file.read()
			sql_stmts = sql_text.split(';')
			for s in sql_stmts:
				if s is not None and len(s.strip()) > 0:
					self.execute(s)
					print s			
		from alluc_api import AllucAPI
		domains = AllucAPI()._get_active_resolvers()
		#domains = ['promptfile.com', 'crunchyroll.com', 'xvidstage.com', 'yourupload.com', 'dailymotion.com', 'cloudy.ec', 'cloudy.eu', 'cloudy.sx', 'cloudy.ch', 'cloudy.com', 'thevideo.me', 'videobb.com', 'stagevu.com', 'mp4stream.com', 'youwatch.org', 'rapidvideo.com', 'play44.net', 'castamp.com', 'daclips.in', 'daclips.com', 'videozed.net', 'videomega.tv', 'movieshd.co', 'bayfiles.com', 'vidzi.tv', 'vidxden.com', 'vidxden.to', 'divxden.com', 'vidbux.com', 'vidbux.to', 'purevid.com', 'thefile.me', 'shared.sx', 'vimeo.com', 'vidplay.net', 'vidspot.net', 'movshare.net', 'speedvideo.net', 'uploadc.com', 'streamcloud.eu', 'sockshare.com', 'vk.com', 'videohut.to', 'letwatch.us', 'royalvids.eu', 'veoh.com', 'donevideo.com', 'mp4star.com', 'vidto.me', 'vivo.sx', 'videotanker.co', 'hugefiles.net', 'youtube.com', 'youtu.be', 'primeshare.tv', 'sharevid.org', 'sharerepo.com', 'video44.net', 'billionuploads.com', 'realvid.net', 'filenuke.com', 'bestreams.net', 'exashare.com', 'limevideo.net', 'videovalley.net', 'divxstage.eu', 'divxstage.net', 'divxstage.to', 'cloudtime.to', 'vidzur.com', 'gorillavid.in', 'gorillavid.com', 'trollvid.net', 'ecostream.tv', 'muchshare.net', 'streamin.to', 'video.tt', '180upload.com', 'auengine.com', 'novamov.com', 'vodlocker.com', 'watchfreeinhd.com', 'uploadcrazy.net', 'tubeplus.me', 'mp4upload.com', 'cyberlocker.ch', 'googlevideo.com', 'picasaweb.google.com', 'jumbofiles.com', 'vidstream.in', 'veehd.com', 'movdivx.com', 'mightyupload.com', 'vidup.org', 'tune.pk', 'facebook.com', 'mrfile.me', 'nowvideo.eu', 'nowvideo.ch', 'nowvideo.sx', 'flashx.tv', 'videoboxone.com', 'vidcrazy.net', 'movreel.com', 'hostingbulk.com', 'played.to', 'putlocker.com', 'filedrive.com', 'firedrive.com', 'mooshare.biz', 'zalaa.com', 'playwire.com', 'vidbull.com', 'sharesix.com', 'movpod.net', 'movpod.in', 'justmp4.com', 'cloudyvideos.com', 'mega-vids.com', 'nosvideo.com', 'movzap.com', 'zuzvideo.com', 'allmyvideos.net', 'videofun.me', 'videoweed.es', 'videoraj.ec', 'videoraj.eu', 'videoraj.sx', 'videoraj.ch', 'videoraj.com']
		for domain in domains:
			self.execute("INSERT INTO hosts(host, title, enabled) VALUES(?,?,0)", [domain, domain])
		self.commit()	
		ADDON.set_setting('database_%s_init' % self.db_type, 'true')
			
class SQLiteDatabase(DatabaseClass):
	def __init__(self, db_file='', quiet=False, maindb=True):
		self.quiet=quiet
		self.db_type = 'sqlite'
		self.lastrowid = None
		self.db_file = db_file		
		self._connect(maindb)

	def _connect(self, maindb):
		global ADDON
		if not self.quiet:
			print "Connecting to " + self.db_file
		try:
			from sqlite3 import dbapi2 as database
			if not self.quiet:
				print "%s loading sqlite3 as DB engine" % ADDON_NAME
		except:
			from pysqlite2 import dbapi2 as database
			if not self.quiet:
				print "%s loading pysqlite2 as DB engine"  % ADDON_NAME
		if not self.quiet:
			print "Connecting to SQLite on: " + self.db_file
		self.DBH = database.connect(self.db_file)
		self.DBC = self.DBH.cursor()
		
		if maindb and ADDON.get_setting('database_sqlite_init') != 'true':
			self._initialize()

class MySQLDatabase(DatabaseClass):
	def __init__(self, host, dbname, username, password, port, quiet=False):
		self.quiet=quiet
		self.db_type = 'mysql'
		self.lastrowid = None
		self.host = host
		self.dbname = dbname
		self.username=username
		self.password = password
		self.port = port
		self._connect()

	def _connect(self):
		global ADDON
		try:	
			import mysql.connector as database
			if not self.quiet:
				print "%s loading mysql.connector as DB engine" % ADDON_NAME
			dsn = {
					"database": self.dbname,
					"host": self.host,
					"port": int(self.port),
					"user": str(self.username),
					"password": str(self.password),
					"buffered": True
			}
			self.DBH = database.connect(**dsn)
		except Exception, e:
			print '****** %s SQL ERROR: %s' % (ADDON_NAME, e)
		self.DBC = self.DBH.cursor()
		if ADDON.get_setting('database_mysql_init') != 'true':
			self._initialize()
	
	def execute(self, SQL, data=[]):					
		try:
			if data:
				SQL = SQL.replace('?', '%s')
				self.DBC.execute(SQL, data)
			else:
				self.DBC.execute(SQL)
			try:
				self.lastrowid = self.DBC.lastrowid
			except:
				self.lastrowid = None
		except Exception, e:
			if IGNORE_UNIQUE_ERRORS and re.match('1062: Duplicate entry', str(e)):				
				print '******SQL ERROR: %s' % e

	def query(self, SQL, data=None, force_double_array=False):
		if data:
			SQL = SQL.replace('?', '%s')
			self.DBC.execute(SQL, data)
		else:
			self.DBC.execute(SQL)
		rows = self.DBC.fetchall()
		if(len(rows)==1 and not force_double_array):
			return rows[0]
		else:
			return rows
