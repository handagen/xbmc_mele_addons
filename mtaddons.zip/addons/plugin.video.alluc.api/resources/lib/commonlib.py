import sys
ARGS = sys.argv
#print ARGS
try:
	int(ARGS[1])
except:
	ARGS.insert(1, -1)
try: 
	str(ARGS[2])
except:
	ARGS.insert(2, "?/fake")
#print sys.argv
import xbmc
import os
import unicodedata
from addon.common.addon import Addon
class MyAddon(Addon):
	def log(self, msg, level=1):
		if int(level) >= int(self.get_setting('log-level')):
			msg = unicodedata.normalize('NFKD', unicode(msg)).encode('ascii','ignore')
			xbmc.log('%s: %s' % (self.get_name(), msg))
	def str2bool(self, v):
		if not v: return False
		return v.lower() in ("yes", "true", "t", "1")
	def get_bool_setting(self, k):
		return(self.str2bool(self.get_setting(k)))
	def raise_error(self, title, message):
		image = self.get_path() + os.sep + 'resources' + os.sep + 'artwork' + os.sep + 'error.jpg'
		xbmc.executebuiltin("XBMC.Notification("+title+","+message+",1500,"+image+")")

ADDON_ID = 'plugin.video.alluc.api'
WINDOW_PREFIX = 'alluc.api'
ADDON = MyAddon(ADDON_ID,ARGS)
ADDON_NAME = ADDON.get_name()
VERSION = ADDON.get_version()
ROOT_PATH = ADDON.get_path()
DATA_PATH = ADDON.get_profile()
LOGVERBOSE = 0
LOGSTANDARD = 1
ADDON.log("Setting verbose log level", LOGVERBOSE)
class Mailer():
	def __init__(self, To, Host):
			import socket
			self.From = 'alluc@%s' % socket.gethostname()
			self.To = To
			if ADDON.get_setting('smtp-ssl')=='true': 
				Host = Host + ":587"
			self.smtp_host = Host
			
	def send(self, subject, msg):
		import re,smtplib
		from email.mime.text import MIMEText
		fh = open(xbmc.translatePath( "special://temp/kodi.log" ), 'r')
		log = fh.read()
		log = re.sub('<host>(.+?)</host>', '<pass>******</pass>', log)
		log = re.sub('<name>(.+?)</name>', '<name>******</name>', log)
		log = re.sub('<user>(.+?)</user>', '<user>******</user>', log)
		log = re.sub('<pass>(.+?)</pass>', '<pass>******</pass>', log)
		msg = MIMEText("%s\n=============== See kodi.log below ===============\n\n%s" % (msg, log))
		fh.close()
		msg['Subject'] = subject
		msg['From'] = self.From
		msg['To'] = self.To
		now=datetime.now()
		day = now.strftime('%a')
		date = now.strftime('%d %b %Y %X')
		msg['Date'] = day + ', ' + date + ' -0000'
		server = smtplib.SMTP(self.smtp_host)
		if ADDON.get_setting('smtp-ssl')=='true':
			server.starttls()
			server.ehlo()
		if ADDON.get_setting('smtp-login') != '' and ADDON.get_setting('smtp-passwd') != '':
			server.login(ADDON.get_setting('smtp-login'),ADDON.get_setting('smtp-passwd'))
		server.sendmail(self.From, [self.To], msg.as_string())
		server.quit()
class FatalError(Exception):
	pass		
class SystemFailure():
	def __init__(self, error_msg, fatal=True):
		try:
			if ADDON.get_setting('smtp-notify')=="true":
				ADDON.log('Sending kodi.log to %s' % ADDON.get_setting('smtp-address'))
				Mailer(ADDON.get_setting('smtp-address'),ADDON.get_setting('smtp-server')).send('Alluc System Failure: ', str(error_msg))
		except:
			pass
		if fatal: raise SystemExit