import urllib2, urllib, re
from urllib2 import URLError, HTTPError
from commonlib import *
from functions import get_str
try: 
	import simplejson as json
except ImportError: 
	import json
import xbmcaddon
ENABLED_COLOR = ADDON.get_setting('custom_color_enabled')
SIZE_COLOR = ADDON.get_setting('custom_color_size')
HOST_COLOR = ADDON.get_setting('custom_color_host')
EXTENSION_COLOR = ADDON.get_setting('custom_color_ext')
MAX_RESULTS = ADDON.get_setting('max-results')

class AllucAPI():
	def __init__(self, base_url='', api_key='', cache_results=False):
		self.api_key = api_key
		self.base_url = base_url
		self.cache_results = cache_results
		self.results = []
		self.domains = False
		self.username = ADDON.get_setting('alluc-username')
		self.password = ADDON.get_setting('alluc-password')
		
	def search(self, query, host=None, lang=None):
		url = self._build_search_url(query, host, lang)
		#print url
		data = self._call(url)
		if data:
			self._get_results(data)
		return self.results
	
	def _get_api_key(self):
		from addon.common.net import Net
		from BeautifulSoup import BeautifulSoup, Tag, NavigableString
		net = Net()
		net.set_user_agent('Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1500.72 Safari/537.36')
		url = 'http://accounts.alluc.com/'
		html = net.http_GET(url).content
		soup = BeautifulSoup(html)
		form = soup.find('form')
		action = form['action']
		inputs = form.findAll('input')
		post_dict = {}
		for input in inputs:
			try:
				post_dict[input['name']] = input['value']
			except:
				pass
		post_dict['loginid'] = self.username
		post_dict['passwd'] = self.password
		html = net.http_POST(url + action, post_dict).content
		soup = BeautifulSoup(html)
		try:
			input = soup.find('input', {"style": "background-color:#ddd;color:#000;font-style:italic;"})
			apikey = input['value']
			self._set_api_key(apikey)
			return True
		except:
			return False
	
	def _set_api_key(self, apikey):
		ADDON.set_setting('alluc-private-key', apikey)
		
	def _build_search_url(self, query, host=None, lang=None):
		params = {"from": 0, "count": MAX_RESULTS, "getmeta":0}
		if ADDON.get_setting('alluc-auth-method') == 'Password':
			params['user'] = self.username
			params['password'] = self.password
		else :
			params['apikey'] = self.api_key
		if host: query = query + ' host:' + host
		if lang: query = query + ' lang:' + lang
		params['query'] = query
		url = "%sstream/?%s" % (self.base_url, urllib.urlencode(params))
		return url
	
	def _get_results(self, data):
		if not self.domains: self.domains = self._get_active_resolvers()
		for result in data['result']:
			title = result['title']
			hoster = result['hosterurls']
			extension = result['extension']
			size = result['sizeinternal']
			extension = result['extension']
			host_name = result['hostername']
			hosts = result['hosterurls']
			for host in hosts:
				#print self.domains
				if host_name in self.domains:
					url = host['url']
					display = "[COLOR %s]%s[/COLOR]" % (HOST_COLOR, host_name)
					if size:
						display = display + " ([COLOR %s]%s[/COLOR])" % (SIZE_COLOR, self.format_size(size))
					if extension:
						display = display + " [COLOR %s]%s[/COLOR]" % (EXTENSION_COLOR, extension.upper())
					display = display + ": %s" % title
					record = {"title": display, "url": url, "host": host_name}
					self.results.append(record)
		
	def _get_active_resolvers(self):
		import urlresolver
		domains = []
		try:
			for resolver in urlresolver.UrlResolver.implementors():
				for domain in resolver.domains:
					if re.match('^(.+?)\.(.+?)$', domain): domains.append(domain)
		except:
			pass
		if len(domains) ==0:
			domains = ['promptfile.com', 'crunchyroll.com', 'xvidstage.com', 'yourupload.com', 'dailymotion.com', 'cloudy.ec', 'cloudy.eu', 'cloudy.sx', 'cloudy.ch', 'cloudy.com', 'thevideo.me', 'videobb.com', 'stagevu.com', 'mp4stream.com', 'youwatch.org', 'rapidvideo.com', 'play44.net', 'castamp.com', 'daclips.in', 'daclips.com', 'videozed.net', 'videomega.tv', 'movieshd.co', 'bayfiles.com', 'vidzi.tv', 'vidxden.com', 'vidxden.to', 'divxden.com', 'vidbux.com', 'vidbux.to', 'purevid.com', 'thefile.me', 'shared.sx', 'vimeo.com', 'vidplay.net', 'vidspot.net', 'movshare.net', 'speedvideo.net', 'uploadc.com', 'streamcloud.eu', 'sockshare.com', 'vk.com', 'videohut.to', 'letwatch.us', 'royalvids.eu', 'veoh.com', 'donevideo.com', 'mp4star.com', 'vidto.me', 'vivo.sx', 'videotanker.co', 'hugefiles.net', 'youtube.com', 'youtu.be', 'primeshare.tv', 'sharevid.org', 'sharerepo.com', 'video44.net', 'billionuploads.com', 'realvid.net', 'filenuke.com', 'bestreams.net', 'exashare.com', 'limevideo.net', 'videovalley.net', 'divxstage.eu', 'divxstage.net', 'divxstage.to', 'cloudtime.to', 'vidzur.com', 'gorillavid.in', 'gorillavid.com', 'trollvid.net', 'ecostream.tv', 'muchshare.net', 'streamin.to', 'video.tt', '180upload.com', 'auengine.com', 'novamov.com', 'vodlocker.com', 'watchfreeinhd.com', 'uploadcrazy.net', 'tubeplus.me', 'mp4upload.com', 'cyberlocker.ch', 'googlevideo.com', 'picasaweb.google.com', 'jumbofiles.com', 'vidstream.in', 'veehd.com', 'movdivx.com', 'mightyupload.com', 'vidup.org', 'tune.pk', 'facebook.com', 'mrfile.me', 'nowvideo.eu', 'nowvideo.ch', 'nowvideo.sx', 'flashx.tv', 'videoboxone.com', 'vidcrazy.net', 'movreel.com', 'hostingbulk.com', 'played.to', 'putlocker.com', 'filedrive.com', 'firedrive.com', 'mooshare.biz', 'zalaa.com', 'playwire.com', 'vidbull.com', 'sharesix.com', 'movpod.net', 'movpod.in', 'justmp4.com', 'cloudyvideos.com', 'mega-vids.com', 'nosvideo.com', 'movzap.com', 'zuzvideo.com', 'allmyvideos.net', 'videofun.me', 'videoweed.es', 'videoraj.ec', 'videoraj.eu', 'videoraj.sx', 'videoraj.ch', 'videoraj.com']
		return domains

	def format_size(self, size):
		size = int(size) / (1024 * 1024)
		if size > 2000:
			size = size / 1024
			unit = 'GB'
		else :
			unit = 'MB'
		size = "%s %s" % (size, unit)
		return size
	
	def _call(self, url, data=None, params=None, return_json=True):
		ADDON.log(url, LOGVERBOSE)
		req = urllib2.Request(url)
		opener = urllib2.build_opener()
		try: response = opener.open(req)
		except HTTPError as e:
			'''if e.code == 511:
				s = get_str(30828)
				ADDON.show_error_dialog(['%s 511:' % s[0], '%s.' % s[1]])
			else:
				s = get_str(30828)
				ADDON.show_error_dialog(['%s %s: %s' % (s[0], e.code, e.reason)])
			ADDON.log('Error code: ' + e.code)
			ADDON.log(url)
			return False'''
			ADDON.log(url)
			error_msg = 'Alluc HTTP Error %s: %s' % ( e.code, e.reason)
			ADDON.show_error_dialog([error_msg])
			SystemFailure(error_msg)
		except URLError as e:
			ADDON.log(url)
			error_msg = 'Alluc URL Error %s: %s' % ( e.code, e.reason)
			ADDON.show_error_dialog([error_msg])
			SystemFailure(error_msg)
		else:
			if return_json:
				data = json.loads(response.read())
				return data
			else:
				return response.read()