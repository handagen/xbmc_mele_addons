import os
import sys
import re
import urllib
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
from commonlib import *
try: 
	import simplejson as json
except ImportError: 
	import json
def normalize(string):
	return unicodedata.normalize('NFKD', unicode(string)).encode('ascii','ignore')

def sys_exit():
	exit = xbmc.executebuiltin("XBMC.ActivateWindow(Home)")
	return exit

def get_str(id):
	local = xbmcaddon.Addon(ADDON_ID).getLocalizedString(id=id)
	local = local.split("||")
	if len(local)==1: return normalize(local[0])
	for i, w in enumerate(local):
		local[i] = normalize(w)
	return local

def REFRESH():
	xbmc.executebuiltin("Container.Refresh")

def Notify(title, message, image=None):
	if not image:
		from vfs import VFSClass
		vfs = VFSClass()
		image = vfs.join(ADDON.get_path(), 'icon.png')
	xbmc.executebuiltin("XBMC.Notification("+title+","+message+",1500,"+image+")")

def Confirm(title, msg1='', msg2=''):
	dialog = xbmcgui.Dialog()
	return dialog.yesno(title, msg1, msg2)

def getKeyVal(item, key):
	try:
		return item[key]
	except:
		return None

def get_active_resolvers():
	import urlresolver
	domains = []
	for resolver in urlresolver.UrlResolver.implementors():
		if resolver.domains:
			for domain in resolver.domains: 
				if re.match('^(.+?)\.(.+?)$', domain): domains.append(domain)
	return domains	

def format_size(size):
	size = int(size) / (1024 * 1024)
	if size > 2000:
		size = size / 1024
		unit = 'GB'
	else :
		unit = 'MB'
	size = "%s %s" % (size, unit)
	return size

def kodi_json_request(method, params):
	jsonrpc =  json.dumps({ "jsonrpc": "2.0", "method": method, "params": params, "id": 1 })
	response = json.loads(xbmc.executeJSONRPC(jsonrpc))
	return response

def get_movieid(title, year):
	params = { "filter": {"and": [
		{"field": "title", "operator": "is", "value": str(title)},
		{"field": "year", "operator": "is", "value": str(year)}
	]}}
	response = kodi_json_request('VideoLibrary.GetMovies', params)
	try:
		return response['result']['movies'][0]['movieid']
	except:
		return False

def get_episodeid(show_title, season, episode):
	params = { "filter": {"and": [
		{"field": "tvshow", "operator": "is", "value": show_title}, 
		{"field": "season", "operator": "is", "value": str(season)}, 
		{"field": "episode", "operator": "is", "value": str(episode)}
	]}, "properties": ["playcount"]}
	response = kodi_json_request('VideoLibrary.GetEpisodes', params)
	try:
		return response['result']['episodes'][0]['episodeid']
	except:
		return False

def get_movie_playcount(movie, year):
	params = { "filter": {"and": [
		{"field": "title", "operator": "is", "value": movie},
		{"field": "year", "operator": "is", "value": str(year)}
	]}, "properties": ["playcount"]}
	response = kodi_json_request('VideoLibrary.GetMovies', params)
	try:
		return response['result']['movies'][0]['movieid'],response['result']['movies'][0]['playcount']
	except:
		return False,False

def get_episode_playcount(show_title, season, episode):
	params = { "filter": {"and": [
		{"field": "tvshow", "operator": "is", "value": show_title}, 
		{"field": "season", "operator": "is", "value": str(season)}, 
		{"field": "episode", "operator": "is", "value": str(episode)}
	]}, "properties": ["playcount"]}
	response = kodi_json_request('VideoLibrary.GetEpisodes', params)
	print response
	try:
		return response['result']['episodes'][0]['episodeid'], response['result']['episodes'][0]['playcount']
	except:
		return False,False
	
class TextBox:
	# constants
	WINDOW = 10147
	CONTROL_LABEL = 1
	CONTROL_TEXTBOX = 5

	def __init__( self, *args, **kwargs):
		# activate the text viewer window
		xbmc.executebuiltin( "ActivateWindow(%d)" % ( self.WINDOW, ) )
		# get window
		self.window = xbmcgui.Window( self.WINDOW )
		# give window time to initialize
		xbmc.sleep( 500 )


	def setControls( self ):
		#get header, text
		heading, text = self.message
		# set heading
		self.window.getControl( self.CONTROL_LABEL ).setLabel( "%s - %s v%s" % ( heading, ADDON_NAME, VERSION) )
		# set text
		self.window.getControl( self.CONTROL_TEXTBOX ).setText( text )

	def show(self, heading, text):
		# set controls

		self.message = heading, text
		self.setControls()
