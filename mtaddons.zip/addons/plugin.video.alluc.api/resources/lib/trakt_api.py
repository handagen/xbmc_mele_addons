import urllib2, urllib
from urllib2 import URLError, HTTPError
from commonlib import *
from functions import get_str
try: 
	import simplejson as json
except ImportError: 
	import json
CLIENT_ID = "7fe0eea41783130c7c3c3c0a99153740e19964bcd84cc488ef0691881e2c5da9"
SECRET_ID = "d0858eff6524270fc1e5dfb6e32583b22aa1111cf5d097214b54f74cc207cce0"
REDIRECT_URI = 'urn:ietf:wg:oauth:2.0:oob'
BASE_URL = "https://api-v2launch.trakt.tv"
PIN_URL = "http://trakt.tv/pin/4428"
DAYS_TO_GET = 21
DECAY = 2
from database import SQLiteDatabase
from vfs import VFSClass
vfs = VFSClass()
CACHE_DB = vfs.join("special://temp", "trakt_cache.db")

class TraktAPI():
	def __init__(self, token="", quiet=False):
		self.quiet = quiet
		self.token = token
		self._cached = False
		self.cache_id = None
		self._authorize()
		if vfs.exists(CACHE_DB):
			self.DB = SQLiteDatabase(CACHE_DB, maindb=False)
			self.DB.execute('PRAGMA foreign_keys = ON')
			self.DB.execute('DELETE FROM trakt_cache WHERE strftime("%s","now") -  strftime("%s",ts) > (3600 * ?)', [DECAY])
			self.DB.commit()
		else:
			self.DB = SQLiteDatabase(CACHE_DB, maindb=False)
			tables = [
			'CREATE TABLE IF NOT EXISTS "trakt_cache"("cache_id" INTEGER PRIMARY KEY AUTOINCREMENT, "uri" TEXT NOT NULL, "cache_type" TEXT NOT NULL, "ts" TIMESTAMP DEFAULT CURRENT_TIMESTAMP)',
			'CREATE TABLE IF NOT EXISTS "movie_cache"("movie_id" INTEGER PRIMARY KEY AUTOINCREMENT, "cache_id" INTEGER, "imdb_id" TEXT, "title" TEXT, "display" TEXT, "year" INTEGER, "fanart" TEXT, "poster" TEXT, FOREIGN KEY(cache_id) REFERENCES trakt_cache(cache_id) ON DELETE CASCADE)',
			'CREATE TABLE IF NOT EXISTS "show_cache"("show_id" INTEGER PRIMARY KEY AUTOINCREMENT, "cache_id" INTEGER, "imdb_id" TEXT, "title" TEXT, "display" TEXT, "year" INTEGER, "fanart" TEXT, "poster" TEXT, FOREIGN KEY(cache_id) REFERENCES trakt_cache(cache_id) ON DELETE CASCADE)',
			'CREATE TABLE IF NOT EXISTS "episode_cache"("episode_id" INTEGER PRIMARY KEY AUTOINCREMENT, "cache_id" INTEGER, "imdb_id" TEXT, "title" TEXT, "series" TEXT, "display" TEXT, "season" INTEGER, "episode" INTEGER, "aired" TEXT, "fanart" TEXT, "poster" TEXT, FOREIGN KEY(cache_id) REFERENCES trakt_cache(cache_id) ON DELETE CASCADE)'
			]
			for table in tables:
				self.DB.execute(table)
			self.DB.commit()
	
	def _authorize(self, pin=None):
		uri = '/oauth/token'
		data = {'client_id': CLIENT_ID, 'client_secret': SECRET_ID, 'redirect_uri': REDIRECT_URI}
		if pin:
			data['code'] = pin
			data['grant_type'] = 'authorization_code'
		else:
			refresh_token = ADDON.get_setting('trakt_refresh_token')
			if refresh_token:
				data['refresh_token'] = refresh_token
				data['grant_type'] = 'refresh_token'
			else:
				ADDON.set_setting('trakt_oauth_token', '')
				ADDON.set_setting('trakt_refresh_token', '')
				ADDON.log("Authentication Error, Please you must authorize Alluc with Tratk.")
				return False
		response = self._call(uri, data, auth=False)
		if response is False:
			ADDON.set_setting('trakt_oauth_token', '')
			ADDON.set_setting('trakt_refresh_token', '')
			return False
		if 'access_token' in response.keys() and 'refresh_token' in response.keys():
			ADDON.set_setting('trakt_oauth_token', response['access_token'])
			ADDON.set_setting('trakt_refresh_token', response['refresh_token'])
			self.token = response['access_token']
			return True

	def add_to_watchlist(self, media, imdb_id):
		uri = '/sync/watchlist'
		data = {media:  [{'ids': {'imdb': imdb_id}}]}
		self._call(uri, data, auth=True)
	
	def remove_from_watchlist(self, media, imdb_id):
		uri = '/sync/watchlist/remove'
		data = {media:  [{'ids': {'imdb': imdb_id}}]}
		self._call(uri, data, auth=True)
	
	def set_watched(self, media, imdb_id, season=None, episode=None):
		uri = '/sync/history'
		if media=='episodes':
			data = {media:[{'ids': {'imdb': imdb_id}}], "seasons": [{"number": season, "episodes":[{"number": episode}]}]}
		else:
			data = {media:  [{'ids': {'imdb': imdb_id}}]}
		print self._call(uri, data, auth=True)
	
	def unset_watched(self, media, imdb_id):
		uri = '/sync/history/remove'
		data = {media:  [{'ids': {'imdb': imdb_id}}]}
		print self._call(uri, data, auth=True)
		
	def search(self, query, media='show'):
		uri = '/search'
		results =  self._call(uri, params={'query': query, 'type': media})
		if media=='show':
			return self._process_records(results, 'show')
		else:
			return self._process_records(results, 'movie')
		
	def get_watchlist_shows(self, DB):
		uri = '/users/me/watchlist/shows'
		response = self._process_records(self._call(uri, params={'extended': 'full,images'}, auth=True), 'show')
		DB.execute("DELETE from favorites WHERE media='TV'")
		for r in response:
			DB.execute("INSERT INTO favorites(media, name, imdb_id) VALUES(?,?,?)", ['TV', r['title'], r['imdb_id']])
		DB.commit()
		return response
	
	def get_watchlist_movies(self, DB):
		uri = '/users/me/watchlist/movies'
		response = self._process_records(self._call(uri, params={'extended': 'full,images'}, auth=True), 'movie')
		DB.execute("DELETE from favorites WHERE media='MOVIE'")
		for r in response:
			DB.execute("INSERT INTO favorites(media, name, imdb_id) VALUES(?,?,?)", ['MOVIE', r['title'], r['imdb_id']])
		DB.commit()
		return response

	def get_collection(self, media):
		uri = '/users/me/collection/%s' % media
		return self._call(uri, params={}, auth=True)

	def get_custom_lists(self):
		uri = '/users/me/lists'
		return sorted(self._call(uri, params={}, auth=True))

	def get_custom_list(self, slug, media):
		if media=='tvshow': media = 'show'
		uri = '/users/me/lists/%s/items' % slug 
		temp = self._call(uri, params={'extended': 'full,images'}, auth=True)
		results = []
		for r in temp:
			if r['type'] == media:
				results.append(r)
		if media=='show':
			return self._process_records(results, 'show')
		else:
			return self._process_records(results, 'movie')
	
	def create_custom_list(self, title):
		uri = '/users/me/lists'
		post_dict = {
			"name": title,
    		"description": "Created by Alluc.API",
  	   		"privacy": "public",
    	   	"display_numbers": True,
		   	"allow_comments": True
		}
		self._call(uri, data=post_dict, auth=True)

	def add_to_custom_list(self, media, slug, imdb_id):
		if media=='MOVIE':
			post_dict = {'movies': [{'ids': {"imdb": imdb_id}}]}
		else:
			post_dict = {'shows': [{'ids': {"imdb": imdb_id}}]}
		uri = '/users/me/lists/%s/items' % slug
		self._call(uri, data=post_dict, auth=True)
		
	def delete_from_custom_list(self, media, slug, imdb_id):
		if media=='MOVIE':
			post_dict = {'movies': [{'ids': {"imdb": imdb_id}}]}
		else:
			post_dict = {'shows': [{'ids': {"imdb": imdb_id}}]}
		uri = '/users/me/lists/%s/items/remove' % slug
		self._call(uri, post_dict, auth=True)
		
	def delete_custom_list(self, slug):
		uri = '/users/me/lists/%s' % slug
		print self._delete(uri)

	def get_trending_movies(self):
		uri = '/movies/trending'
		media='movie'
		return self._process_records(self._call(uri, params={'extended': 'full,images'}, cache=media), media)

	def get_popular_movies(self):
		uri = '/movies/popular'
		media = 'movie'
		return self._process_records(self._call(uri, params={'extended': 'full,images'}, cache=media), media)
	
	def get_recommended_movies(self):
		uri = '/recommendations/movies'
		media = 'movie'
		return self._process_records(self._call(uri, params={'extended': 'full,images'}, cache=media, auth=True), media)
	
	def _process_records(self, records, media='movie'):
		if self._cached:
			SQL = "SELECT * FROM %s_cache WHERE cache_id=?" % media
			rows = self.DB.query_assoc(SQL, [records[0]])
			return rows
		processed = []
		if media=='episode':
			from datetime import datetime
			import re, time
			#timezone = json.loads(xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "Settings.GetSettingValue", "params": {"setting": "locale.timezone"}, "id": 1}'))['result']['value']
			for record in records:
				if 'episode' in record.keys():
					tmp = re.match('^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})\.000Z', record['episode']['first_aired'])
					aired = datetime(int(tmp.group(1)), int(tmp.group(2)),int(tmp.group(3)),int(tmp.group(4)),int(tmp.group(5)),int(tmp.group(6)))
					aired = time.mktime(aired.timetuple())
					series = record['show']['title']
					season = record['episode']['season']
					episode = record['episode']['number']
					series = record['show']['title']
					title = record['episode']['title']
					poster = record['show']['images']['poster']['full']
					fanart = record['show']['images']['fanart']['full']
					imdb_id = record['show']['ids']['imdb']
					display = "%s %sx%s %s" %(series, season, episode, title)
					processed.append({'imdb_id': imdb_id, 'title': title, "poster": poster, "fanart": fanart, "display": display, "series": series, "season": season, "episode": episode, "aired": aired})
					if self._cached is False and self.cache_id is not None:
						SQL = "INSERT INTO %s_cache(cache_id, imdb_id, title, display, series, season, episode, aired, fanart, poster) VALUES(?,?,?,?,?,?,?,?,?,?)" % media
						self.DB.execute(SQL, [self.cache_id, imdb_id, title, display, series, season, episode, aired, fanart, poster])
				else:
					if 'first_aired' in record.keys() and record['first_aired'] is not None:
						tmp = re.match('^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})\.000Z', record['first_aired'])
						aired = datetime(int(tmp.group(1)), int(tmp.group(2)),int(tmp.group(3)),int(tmp.group(4)),int(tmp.group(5)),int(tmp.group(6)))
						aired = time.mktime(aired.timetuple())
						now = time.mktime(datetime.now().timetuple())
						if aired < now:
							title = record['title']
							season = record['season']
							episode = record['number']
							poster = record['images']['screenshot']['full']
							display = "%sx%s - %s" % (season, episode, title)
							processed.append({'title': title, "display": display, "poster": poster, "season": season, "episode": episode, "aired": aired})
							if self._cached is False and self.cache_id is not None:
								SQL = "INSERT INTO %s_cache(cache_id, title, display, season, episode, aired) VALUES(?,?,?,?,?,?)" % media
								self.DB.execute(SQL, [self.cache_id, title, display, season, episode, aired])
			if self._cached is False: 
				self.DB.commit()
			return processed
		for record in records:
			if media in record:
				title = record[media]['title']
				imdb_id = record[media]['ids']['imdb']
				poster = record[media]['images']['poster']['full']
				fanart = record[media]['images']['fanart']['full']
				try:
					year = record[media]['released'][0:4]
				except:
					year = record[media]['year']
			else:
				title = record['title']
				imdb_id = record['ids']['imdb']
				poster = record['images']['poster']['full']
				fanart = record['images']['fanart']['full']
				try:
					year = record['released'][0:4]
				except:
					year = record['year']
			if title is not None:
				display = "%s (%s)" % (title, year)
				processed.append({'imdb_id': imdb_id, 'title': title, "poster": poster, "fanart": fanart, "display": display, "year": year})
				if self._cached is False and self.cache_id is not None:
					SQL = "INSERT INTO %s_cache(cache_id, imdb_id, title, display, year, fanart, poster) VALUES(?,?,?,?,?,?,?)" % media
					self.DB.execute(SQL, [self.cache_id, imdb_id, title, display, year, fanart, poster])
		if self._cached is False and self.cache_id is not None: 
			self.DB.commit()
		return processed
	
	def get_trending_shows(self):
		uri = '/shows/trending'
		media = 'show'
		return self._process_records(self._call(uri, params={'extended': 'full,images'}, cache=media), media)

	def get_popular_shows(self):
		uri = '/shows/popular'
		media = 'show'
		return self._process_records(self._call(uri, params={'extended': 'full,images'}, cache=media), media)
	
	def get_recommended_shows(self):
		uri = '/recommendations/shows'
		media = 'show'
		return self._process_records(self._call(uri, params={'extended': 'full,images'}, cache=media, auth=True), media)
	
	def get_show_seasons(self, imdb_id):
		uri = '/shows/%s/seasons' % imdb_id
		return self._call(uri, params={'extended': 'images'})
	
	def get_show_episodes(self, imdb_id, season):
		uri = '/shows/%s/seasons/%s' % (imdb_id, season)
		media='episode'
		return self._process_records(self._call(uri, params={'extended': 'full,images'}, cache=media), media)
	
	def get_episode_screenshot(self, imdb_id, season, episode):
		uri = '/shows/%s/seasons/%s/episodes/%s' %(imdb_id, season, episode)
		response = self._call(uri, params={'extended': 'images'})
		return response['images']['screenshot']['full']
	
	def get_show_info(self, imdb_id, episodes=False):
		if episodes:
			uri = '/shows/%s/seasons' % imdb_id
			return self._call(uri, params={'extended': 'episodes,full'})
		else:
			uri = '/shows/%s' % imdb_id
			return self._call(uri)
	
	def get_movie_info(self, imdb_id):
		uri = '/movies/%s' % imdb_id
		return self._call(uri, params={})
	
	def get_episode_info(self, imdb_id, season, episode):
		uri = '/shows/%s/seasons/%s/episodes/%s' % (imdb_id, season, episode)
		response = self._call(uri, params={'extended': 'images'})
		
	def get_calendar_shows(self):
		from datetime import date, timedelta
		d = date.today() - timedelta(days=DAYS_TO_GET)
		today = d.strftime("%Y-%m-%d")
		uri = '/calendars/my/shows/%s/%s' % (today, DAYS_TO_GET)
		media='episode'
		return self._process_records(self._call(uri, params={'extended': 'full,images'}, cache=media, auth=True), media)
	
	def _call(self, uri, data=None, params=None, auth=False, cache=False):
		if cache:
			cached = self.DB.query("SELECT cache_id, cache_type,strftime('%s','now') -  strftime('%s',ts) < (3600 * ?) as 'fresh' FROM trakt_cache WHERE uri=? AND fresh=1", [DECAY, uri])
			if len(cached) > 0:
				ADDON.log("Loading cached trakt results", LOGVERBOSE)
				self._cached = cache
				return cached
			else:
				self.DB.execute("INSERT INTO trakt_cache(cache_type, uri) VALUES(?,?)", [cache, uri])
				self.DB.commit()
				self.cache_id = self.DB.lastrowid
				self._cached = False
		json_data = json.dumps(data) if data else None
		headers = {'Content-Type': 'application/json', 'trakt-api-key': CLIENT_ID, 'trakt-api-version': 2}
		if auth: headers.update({'Authorization': 'Bearer %s' % (self.token)})
		url = '%s%s' % (BASE_URL, uri)
		if params:
			params['limit'] = 100
		else:
			params = {'limit': 100}
		url = url + '?' + urllib.urlencode(params)
		ADDON.log(url, LOGVERBOSE)
		try:
			request = urllib2.Request(url, data=json_data, headers=headers)
			f = urllib2.urlopen(request)
			result = f.read()
			response = json.loads(result)
		except HTTPError as e:
			ADDON.log(url)
			ADDON.log(headers)
			error_msg = 'Trakt HTTP Error %s: %s' % ( e.code, e.reason)
			if self.quiet ==False:
				ADDON.show_error_dialog([error_msg])
			SystemFailure(error_msg)
		except URLError as e:
			ADDON.log(url)
			error_msg = 'Trakt URL Error %s: %s' % ( e.code, e.reason)
			if self.quiet ==False:
				ADDON.show_error_dialog([error_msg])
			SystemFailure(error_msg)
		else:
			return response
	
	def _delete(self, uri, data=None, params=None, auth=True):
		json_data = json.dumps(data) if data else None
		url = '%s%s' % (BASE_URL, uri)
		opener = urllib2.build_opener(urllib2.HTTPHandler)
		headers = {'Content-Type': 'application/json', 'trakt-api-key': CLIENT_ID, 'trakt-api-version': 2}
		if auth: headers.update({'Authorization': 'Bearer %s' % (self.token)})
		request = urllib2.Request(url, data=json_data, headers=headers)
		request.get_method = lambda: 'DELETE'
		response = opener.open(request)
