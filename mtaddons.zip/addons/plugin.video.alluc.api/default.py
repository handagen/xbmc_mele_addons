#!/usr/bin/python
#Alluc
'''
    Copyright (C) 2015 DudeHere

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

############################
### Imports		 		###
############################	

import urllib2
import urllib
import sys
import os
import re
import xbmc
import xbmcplugin
import xbmcgui
import xbmcaddon
import unicodedata
import string
from BeautifulSoup import BeautifulSoup, Tag, NavigableString
sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'resources', 'lib'))
import hashlib
try: 
	import simplejson as json
except ImportError: 
	import json
from urllib import quote_plus
from addon.common.net import Net
from metahandler import metahandlers
from commonlib import *
from functions import *
from vfs import VFSClass
net = Net()
vfs = VFSClass()
############################
### Enviornment		 	 ###
############################
ART_PATH = ROOT_PATH + '/resources/artwork'
FANART = vfs.join(ROOT_PATH, 'fanart.jpg')
ICON = vfs.join(ROOT_PATH, 'icon.png')
hash_id = None
BASE_URL = ADDON.get_setting('alluc-url')
if not vfs.exists("special://userdata/addon_data/%s" % ADDON_ID):
	vfs.mkdir("special://userdata/addon_data/%s" % ADDON_ID)
if ADDON.get_bool_setting('movie_custom_directory'):
	MOVIE_DIRECTORY = ADDON.get_setting('movie_directory')
else:
	MOVIE_DIRECTORY = "special://userdata/addon_data/%s/movies" % ADDON_ID
if ADDON.get_bool_setting('tv_show_custom_directory'):
	TVSHOW_DIRECTORY = ADDON.get_setting('tv_show_directory')
else:
	TVSHOW_DIRECTORY = "special://userdata/addon_data/%s/tvshows" % ADDON_ID
	
BASE_URL = ADDON.get_setting('alluc-url')
if ADDON.get_setting('alluc-auth-method') == 'Password':
	APIKEY = None
else:
	APIKEY=ADDON.get_setting('alluc-private-key')
if ADDON.get_setting('cache-search-results')=='true':
	CACHE_RESULTS = True
else :
	CACHE_RESULTS = False
if ADDON.get_setting('filter-results')=='true':
	FILTER_RESULTS = True
else:
	FILTER_RESULTS = False
if ADDON.get_setting('use-metadata')=='true':
	USE_METADATA=True
else:
	USE_METADATA=False
if ADDON.get_setting('sort-results')=='true':
	SORT_BY_HOST = True
else:
	SORT_BY_HOST = False
if ADDON.get_setting('filter-lang')!='-- All --':
	from language import LanguageClass
	FILTER_LANG = LanguageClass().get_code_by_lang(ADDON.get_setting('filter-lang'))
else:
	FILTER_LANG = False

ADVANCED_MODE = ADDON.get_setting('advanced_mode_1') == 'true'

ENABLED_COLOR = ADDON.get_setting('custom_color_enabled')
SIZE_COLOR = ADDON.get_setting('custom_color_size')
HOST_COLOR = ADDON.get_setting('custom_color_host')
EXTENSION_COLOR = ADDON.get_setting('custom_color_ext')
NUMBER_THREADS = int(ADDON.get_setting('use-threadpool'))
MAX_RESULTS = int(ADDON.get_setting('max-results'))
SMART_FILTER = True
############################
### Database		     ###
############################
IGNORE_UNIQUE_ERRORS = True
if ADDON.get_setting('database_mysql')=='true':
	DB_NAME = ADDON.get_setting('database_mysql_name')
	DB_USER = ADDON.get_setting('database_mysql_user')
	DB_PASS = ADDON.get_setting('database_mysql_pass')
	DB_PORT = ADDON.get_setting('database_mysql_port')
	DB_ADDRESS = ADDON.get_setting('database_mysql_host')
	DB_TYPE = 'mysql'
	from database import MySQLDatabase
	DB=MySQLDatabase(DB_ADDRESS, DB_NAME, DB_USER, DB_PASS, DB_PORT)
else:
	from database import SQLiteDatabase
	DB_TYPE = 'sqlite'
	DB_FILE = xbmc.translatePath(ADDON.get_setting('database_sqlite_file'))
	DB=SQLiteDatabase(DB_FILE)

############################
### Initial Setup	     ###
############################

def VersonCheck():
	'''if ADDON.get_setting('setup_run') != 'true':
		win = xbmcgui.Window(10000)
		win.setProperty(WINDOW_PREFIX+'.setup', "true")
		xbmc.executebuiltin('RunScript("plugin.video.alluc.api", "")')
		while True:
			if win.getProperty(WINDOW_PREFIX+'.setup') == "false":
				break
			xbmc.sleep(250)
		SetupLibrary(True)
		if win.getProperty(WINDOW_PREFIX+'.setup_run') == "true":
			ADDON.set_setting('alluc-username',win.getProperty(WINDOW_PREFIX+'.alluc-username'))
			ADDON.set_setting('alluc-password',win.getProperty(WINDOW_PREFIX+'.alluc-password'))
			ADDON.set_setting('setup_run',"true")
			ADDON.set_setting('version',VERSION)
			win.setProperty(WINDOW_PREFIX+'.setup_run', '')			
			win.setProperty(WINDOW_PREFIX+'.alluc-username', '')
			win.setProperty(WINDOW_PREFIX+'.alluc-password', '')
	current = VERSION
	previous = ADDON.get_setting('version')
	update = _check_version(previous, current)
	if update:
		RunUpdate()'''
	win = xbmcgui.Window(10000)
	last_setup_notify = ADDON.get_setting('last_setup_notify')
	run_setup = False
	if last_setup_notify == 'false':
		run_setup = True
	elif last_setup_notify == 'true':
		run_setup = False
	else:
		import time
		now = float(time.time())
		if now - float(last_setup_notify) > 60:
			run_setup = True
		else: print now - float(last_setup_notify)

	if run_setup:
		win.setProperty(WINDOW_PREFIX+'.setup', "true")
		xbmc.executebuiltin('RunScript("plugin.video.alluc.api", "")')
		while True:
			if win.getProperty(WINDOW_PREFIX+'.setup') == "false":
				break
			xbmc.sleep(250)
		SetupLibrary(True)
		current = VERSION
		previous = ADDON.get_setting('version')
		update = _check_version(previous, current)
		if update:
			RunUpdate()

def _check_version(previous, current):
	if not re.search('\d+\.\d+\.\d+', str(previous)): return True
	p = previous.split('.')
	c = current.split('.')	
	# test major version
	if int(p[0]) < int(c[0]): return True
	# test minor version
	if int(p[1]) < int(c[1]): return True
	# test sub minor version
	if int(p[2]) < int(c[2]): return True
	return False
		
def RunUpdate():
	print "update"
	ADDON.set_setting('version',VERSION)

def ResetAlluc():
	xbmc.executebuiltin('RunScript("plugin.video.alluc.api", "mode=reset")')

############################
### Menu Stuff		     ###
############################
	
class ContextMenu:
	def __init__(self):
		self.commands = []

	def add(self, text, arguments={}, require_auth=False):
		if require_auth and (ADDON.get_setting('trakt_oauth_token') == '' or ADVANCED_MODE==False): return
		cmd = self._build(arguments)
		self.commands.append((text, cmd, ''))
	
	def _build(self, arguments):
		cmd = 'XBMC.RunPlugin(%s?' % sys.argv[0]
		for key, item in arguments.items():
			if item: item = urllib.quote_plus(item.encode('utf-8'))
			cmd = "%s&%s=%s" %(cmd, urllib.quote_plus(str(key)), item)
		cmd = cmd + ')'
		return cmd

	def get(self):
		self.add(get_str(30702), {"mode": "set_language"})
		self.add("Run Setup", {"mode": "run_setup"})
		self.add(get_str(30720), {"mode": "tv_watchlist"}, require_auth=True)
		self.add(get_str(30721), {"mode": "movie_watchlist"}, require_auth=True)
		return self.commands
			
def setView(view, content=None, viewid=None):
	if ADDON.get_setting('enable-default-views') == 'true':
		if content:
			xbmcplugin.setContent(int(sys.argv[1]), content)
		if not viewid:
			viewid = ADDON.get_setting(view)
		xbmc.executebuiltin("Container.SetViewMode(%s)" % viewid)
		xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_UNSORTED )
		xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_LABEL )
		xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_VIDEO_RATING )
		xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_DATE )
		xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_PROGRAM_COUNT )
		xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_VIDEO_RUNTIME )
		xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_GENRE )

def EOD(view='default-folder-view', content=None, viewid=None):
	if view=='custom':
		setView('custom', content=content, viewid=viewid)
	else:
		setView(view,content=content)
	ADDON.end_of_directory()

def MENU_ITEM(data, info, image=None, fanart=None, menu=None, isPlayable=False, require_auth=False):
	if require_auth and (ADDON.get_setting('trakt_oauth_token') == '' or ADVANCED_MODE==False): return
	if not vfs.exists(fanart): 
		fanart=FANART
	if not vfs.exists(image): 
		image=ICON
	if not menu:
		menu=ContextMenu()
	if isPlayable: 
		isFolder = False
	else:
		isFolder = True
	ADDON.add_directory(data, info, img=image, fanart=fanart, contextmenu_items=menu.get(), is_folder=isFolder)

class ProgressClass(xbmcgui.DialogProgress):
	def __init__(self, *args, **kwargs):
		xbmcgui.DialogProgress.__init__(self, *args, **kwargs)
		self._silent = False
		self._index = 0
		self._total = 0
		self._percent = 0
	def new(self, heading, total):
		if not self._silent:
			self._index = 0
			self._total = total
			self._percent = 0
			self._heading = heading
			self.create(heading)
			self.update(0, heading, '')
	def next(self, subheading):
		if not self._silent:
			self._index = self._index + 1
			self._percent = self._index * 100 / self._total
			PB.update(self._percent, self._heading, subheading)

PB = ProgressClass()
############################
### Main Functions		 ###
############################

def SetupLibrary(quite=False):
	source_path = vfs.join('special://profile/', 'sources.xml')
	try:
		soup = vfs.read_file(source_path, soup=True)
	except:
		soup = BeautifulSoup()
		sources_tag = Tag(soup, "sources")
		soup.insert(0, sources_tag)
		
	if soup.find("video") == None:
		sources = soup.find("sources")
		video_tag = Tag(soup, "video")
		sources.insert(0, video_tag)
		
	video = soup.find("video")
	if len(soup.findAll(text="Movies (%s)" % ADDON_NAME)) < 1:
		movie_source_tag = Tag(soup, "source")
		movie_name_tag = Tag(soup, "name")
		movie_name_tag.insert(0, "Movies (%s)" % ADDON_NAME)
		MOVIES_PATH_tag = Tag(soup, "path")
		MOVIES_PATH_tag['pathversion'] = 1
		MOVIES_PATH_tag.insert(0, MOVIE_DIRECTORY)
		movie_source_tag.insert(0, movie_name_tag)
		movie_source_tag.insert(1, MOVIES_PATH_tag)
		video.insert(2, movie_source_tag)

	if len(soup.findAll(text="TV Shows (%s)" % ADDON_NAME)) < 1:	
		tvshow_source_tag = Tag(soup, "source")
		tvshow_name_tag = Tag(soup, "name")
		tvshow_name_tag.insert(0, "TV Shows (%s)" % ADDON_NAME)
		tvshow_path_tag = Tag(soup, "path")
		tvshow_path_tag['pathversion'] = 1
		tvshow_path_tag.insert(0, TVSHOW_DIRECTORY)
		tvshow_source_tag.insert(0, tvshow_name_tag)
		tvshow_source_tag.insert(1, tvshow_path_tag)
		video.insert(2, tvshow_source_tag)
	string = ""
	for i in soup:
		string = string + str(i)
	vfs.write_file(source_path, str(soup))
	if not quite:
		dialog = xbmcgui.Dialog()
		s = get_str(30801)
		dialog.ok(s[0], "%s:" % s[1], " 1) [B]%s.[/B]" % s[2], " 2) %s." % s[3])

def ShowInstructions():
	try:
		temp = vfs.read_file(vfs.join("special://userdata", "guisettings.xml"), soup=True)
		language = temp.find('locale').find('language').text.lower()
	except:
		language = 'english'
	path = vfs.join(ROOT_PATH + '/resources/language/%s' % language, 'instructions.txt')
	if vfs.exists(path) is False:
		path = vfs.join(ROOT_PATH + '/resources/language/english', 'instructions.txt')
	color_map = [('%C%', ENABLED_COLOR), ('%C2%', SIZE_COLOR), ('%C3%', HOST_COLOR)]
	content=vfs.read_file(path)
	for f,c in color_map:
		content = content.replace(f,c)
	TextBox().show(get_str(30741), content)

def Autoupdate(media, quiet=False):
	ADDON.log( "Update: " + media)
	from trakt_api import TraktAPI
	trakt = TraktAPI(quiet=quiet)
	if media=='TV':
		shows = DB.query("SELECT imdb_id, title FROM subscriptions WHERE enabled=1", force_double_array=True)
		for show in shows:
			UpdateSubscription(show[0], quiet=quiet)
			xbmc.sleep(50)
		lists = DB.query("SELECT media, slug, id FROM lists WHERE media='tvshow' AND sync=1", force_double_array=True)
		for li in lists:
			shows = trakt.get_custom_list(li[1], li[0])
			for show in shows:
				UpdateSubscription(show['imdb_id'], quiet=quiet)
				xbmc.sleep(50)
		if ADDON.get_setting('update_library')=='true':
			xbmc.executebuiltin('UpdateLibrary(video,' + TVSHOW_DIRECTORY + ')')			
	elif media=='LIBRARY':
		xbmc.executebuiltin('UpdateLibrary(video,' + TVSHOW_DIRECTORY + ')')
		xbmc.executebuiltin('UpdateLibrary(video,' + MOVIE_DIRECTORY + ')')
	else:
		lists = DB.query("SELECT media, slug, id FROM lists WHERE media='movie' AND sync=1", force_double_array=True)
		for li in lists:
			movies = trakt.get_custom_list(li[1], li[0])
			DB.execute("DELETE FROM list_movies WHERE list_id=?", [li[2]])
			for movie in movies:
				AddMovieToLibrary(movie['imdb_id'], list_id=li[2])
				xbmc.sleep(50)
			DB.commit()
		if ADDON.get_setting('update_library')=='true':
				xbmc.executebuiltin('UpdateLibrary(video,' + MOVIE_DIRECTORY + ')')

def UpdateSubscription(imdb_id, quiet=False):
	from trakt_api import TraktAPI
	trakt = TraktAPI(quiet=quiet)
	show = trakt.get_show_info(imdb_id, False)
	series = vfs.clean_file_name(show['title'])
	show_path = vfs.join(TVSHOW_DIRECTORY, series, preserve=False)
	vfs.mkdir(show_path, recursive=True)
	show = trakt.get_show_info(imdb_id, True)
	for row in show:
		if 'episodes' in row.keys():
			season = row['episodes'][0]['season']
			if season > 0:
				season_path = vfs.join(show_path, "Season %s" % season, preserve=False)
				vfs.mkdir(season_path)
				for ep in row['episodes']:
					doit = True
					if ADDON.get_setting('import_aired_only')=='true':
						doit = check_air_date(ep['first_aired'])
					if doit:
						episode = ep['number']
						filename = "%s S%sE%s.strm" % (series, str(season).zfill(2), str(episode).zfill(2))
						full_path =  vfs.join(season_path, filename, preserve=False)
						params = {"mode": "watch_stream", "media": "episode", "imdb_id": imdb_id, "season":season, "episode": episode, "trakt": ep['ids']['trakt']}
						url = "plugin://%s/?%s" % (ADDON_ID, urllib.urlencode(params))
						create_str_file(full_path, url)

def create_str_file(full_path, url):
	create_file = True
	if ADDON.get_setting('overwrite_strm_files')=='false':
		if vfs.exists(full_path):
			create_file = False
	if create_file:
		file = vfs.open(full_path,'w')
		file.write(url)
		file.close()

def check_air_date(aired):
	if aired:
		from datetime import date
		now = date.today()
		match = re.search('^(.+?)-(.+?)-(.+?)T', aired)
		y = int(match.group(1))
		m = int(match.group(2))
		d = int(match.group(3))
		aired = date(y,m,d)
		if aired < now:
			return True
		else: 
			return False
		
def ToggleWatchedState():
	if args['media']=='episode':
		metadata ={"media": args['media'], "title": args['title'], "imdb_id": args['imdb'], "season": args['season'], "episode": args['episode'], "year": ''}
	if args['mode']=='mark_watched':
		SetPlayCount(metadata, 1)
	else:
		SetPlayCount(metadata, 0)

def SetPlayCount(metadata, playcount):
	#from trakt_api import TraktAPI
	#trakt = TraktAPI()
	mark = playcount + 6
	ADDON.log('Mark it %s' % mark)
	try:
		MH = metahandlers.MetaData()
		MH.change_watched(metadata['media'], metadata['title'], metadata['imdb_id'], season=metadata['season'], episode=metadata['episode'], year=metadata['year'], watched=mark)
	except:
		pass
	if metadata['media'] == 'episode':
		if 'show' in metadata.keys():
			show_title = metadata['show']
		else:
			show_title = metadata['title']
		episodeid, playcount = get_episode_playcount(show_title, metadata["season"], metadata["episode"])
		if episodeid:
			if mark == 7:
				playcount = playcount + 1
			else:
				playcount = 0
			params = {"episodeid" : int(episodeid), "playcount": playcount}
			response = kodi_json_request("VideoLibrary.SetEpisodeDetails", params)
			ADDON.log(response)
	else:
		movieid, playcount = get_movie_playcount(metadata["title"], metadata["year"])
		if movieid:
			if mark == 7:
				playcount = playcount + 1
			else:
				playcount = 0
			params = {"movieid" : movieid, "playcount": playcount}
			response = kodi_json_request("VideoLibrary.SetMovieDetails", params)
	REFRESH()

def SetResumePoint(metadata):
	if metadata['media'] == 'episode':
		if 'show' in metadata.keys():
			show_title = metadata['show']
		else:
			show_title = metadata['title']
		episodeid = get_episodeid(show_title, metadata["season"], metadata["episode"])
		if episodeid:
			DB.execute("INSERT INTO player_state(video_id, media, current, total) VALUES(?,'episode',?,?)", [episodeid, args['position'], args['total']])
			DB.commit()
	else:
		movieid = get_movieid(metadata['title'], metadata['year'])
		if movieid:
			DB.execute("INSERT INTO player_state(video_id, media, current, total) VALUES(?,'movie',?,?)", [movieid, args['position'], args['total']])
			DB.commit()
	#REFRESH()
	
def SyncList(title, slug, media):
	DB.execute("INSERT INTO lists(list, slug, media) VALUES(?,?,?,?)", [title, slug, media])
	DB.commit()
	Notify("%s:" % get_str(30802), title)
	REFRESH()
	
def UnSyncList(title, slug):
	dialog = xbmcgui.Dialog()
	s=get_str(30844)
	if dialog.yesno("Remove Sync", "%s %s?" % (s[1],title)):
		DB.execute("UPDATE lists SET sync=0 WHERE slug=?", [slug])
		DB.commit()
		Notify("%s:" % get_str(30803), title)
		REFRESH()

def Subscribe(imdb_id, title):
	ADDON.log("Subscribe " + imdb_id)
	DB.execute("INSERT INTO subscriptions(imdb_id, title) VALUES(?,?)", [imdb_id, title])
	DB.commit()
	UpdateSubscription(imdb_id)
	Notify("%s:" % get_str(30804), title)
	
def Unsubscribe(imdb_id, title):
	ADDON.log("Unsubscribe " + imdb_id)
	dialog = xbmcgui.Dialog()
	s = get_str(30843)
	if dialog.yesno(s[0], "%s %s?" % (s[1], title)):
		DB.execute("DELETE FROM subscriptions WHERE imdb_id=?", [imdb_id])
		DB.commit()
		series = vfs.clean_file_name(title)
		show_path = vfs.join(TVSHOW_DIRECTORY, series)
		vfs.rm(show_path, recursive=True)
		REFRESH()
		Notify("%s:" % get_str(30805), title)

def AddMovieToLibrary(imdb_id, list_id=False):
	#ADDON.log("Import movie " + imdb_id)
	from trakt_api import TraktAPI
	trakt = TraktAPI()
	movie = trakt.get_movie_info(imdb_id)
	movie_title = vfs.clean_file_name(movie['title'])
	movie_path = vfs.join(MOVIE_DIRECTORY, movie_title, preserve=False)
	vfs.mkdir(movie_path, recursive=True)
	filename = "%s.strm" % movie_title
	full_path =  vfs.join(movie_path, filename, preserve=False)
	params = {"mode": "watch_stream", "media": "movie", "imdb_id": imdb_id}
	url = "plugin://%s/?%s" % (ADDON_ID, urllib.urlencode(params))
	create_str_file(full_path, url)
	if list_id:
		DB.execute("INSERT INTO list_movies(list_id, imdb_id, path) VALUES(?,?,?)", [list_id, imdb_id, movie_path])
	Notify("%s:" % get_str(30806), movie_title)
	
def EnableSubscription(imdb_id):
	ADDON.log("Enable subscription %s" % imdb_id)
	DB.execute("UPDATE subscriptions SET enabled=1 WHERE imdb_id=?", [imdb_id])
	DB.commit()
	REFRESH()

def DisableSubscription(imdb_id):
	ADDON.log("Disable subscription %s" % imdb_id)
	DB.execute("UPDATE subscriptions SET enabled=0 WHERE imdb_id=?", [imdb_id])
	DB.commit()
	REFRESH()

def AddFavorite(media, title, imdb_id):
	from trakt_api import TraktAPI
	trakt = TraktAPI()
	if media=='TV':
		trakt.add_to_watchlist('shows', imdb_id)
	DB.execute("INSERT INTO favorites(media, name, imdb_id) VALUES(?,?,?)", [media, title, imdb_id])
	DB.commit()
	#REFRESH()
	Notify("%s:" % get_str(30807), title)

def ListSubscriptions():
	rows = DB.query("SELECT imdb_id, title, enabled FROM subscriptions ORDER BY title ASC", force_double_array=True)
	for row in rows:
		Ct = ContextMenu()
		if row[2]==1:
			Ct.add(get_str(30808), {"mode": "tv_disable_subscription", "title": row[1], "imdb_id": row[0], "title": row[1]})
			display = "[COLOR %s]%s[/COLOR]" % (ENABLED_COLOR, row[1])
		else:
			Ct.add(get_str(30809), {"mode": "tv_enable_subscription", "title": row[1], "imdb_id": row[0], "title": row[1]})
			display = row[1]
		Ct.add(get_str(30810), {"mode": "tv_unsubscribe", "title": row[1], "imdb_id": row[0], "title": row[1]})
		MENU_ITEM({'mode': 'update_subscription', 'imdb_id': row[0]}, {"title": display}, menu=Ct)
	EOD("default-list_view")
	
def RemoveFavorite(media, title, imdb_id):
	dialog = xbmcgui.Dialog()
	s = get_str(30842)
	if dialog.yesno(s[0], "%s %s?" % (s[1], title)):
		from trakt_api import TraktAPI
		trakt = TraktAPI()
		if media=='TV':
			trakt.remove_from_watchlist('shows', imdb_id)
		DB.execute("DELETE FROM favorites WHERE imdb_id=?", [imdb_id])
		DB.commit()
		REFRESH()
		Notify("%s:" % get_str(30811), title)

def ToggleHost(host):
	DB.execute("UPDATE hosts SET enabled=abs(enabled-1) WHERE host=?", [host])
	DB.commit()
	REFRESH()

def ManageHostList():
	rows = DB.query("SELECT host, enabled FROM hosts ORDER BY host ASC", force_double_array=True)
	for row in rows:
		if row[1] == 1:
			display = "[COLOR %s]%s[/COLOR]" % (ENABLED_COLOR, row[0])
		else:
			display = row[0]
		MENU_ITEM({'mode': 'toggle_host', 'host': row[0]}, {"title": display})
	EOD("default-list_view")

def SelectLanguage():
	'''from language import LanguageClass
	lang = LanguageClass()
	dialog = xbmcgui.Dialog()
	choice = dialog.select(get_str(30812), lang.get_languages())
	if choice < 0:
		choice = lang.get_languages()[choice]
		ADDON.set_setting('filter-lang', choice)
		Notify("%s:" % get_str(30813), choice)'''
	xbmc.executebuiltin('RunScript("plugin.video.alluc.api", "mode=set_language")')

def AllucSearch(query=None, silent=False):
	if not query:
		query = DoSearch('Search ' + ADDON_NAME)
		if query == 'What the Furk?': 
			ADDON.set_setting('show-furk', 'true')
			Notify("Furk.net", "Ok I'll enable Furk.",ART_PATH+'/furk.png')
			return
		elif not query: return
	cached_results = False
	if CACHE_RESULTS:			# Are we caching search results, if so check the database for freshly cached results
		rows = DB.query("SELECT display, url, host FROM cache_status WHERE fresh=1 AND hash_id=?", [hash_id], force_double_array=True)
		if rows:
			print "Loading from cache"
			results = []
			for row in rows:
				record = {"title": row[0], "url": row[1], "host": row[2]}
				results.append(record)
			cached_results = True
	if not cached_results:		# No cached results, so lets search
		results = []
		from alluc_api import AllucAPI
		alluc = AllucAPI(BASE_URL, APIKEY, CACHE_RESULTS)
		if FILTER_RESULTS:		# Are we limiting search resutls to host list
			hosts = DB.query("SELECT host FROM hosts WHERE enabled=1", force_double_array=True)
			temp = []
			for host in hosts: temp.append(host[0])
			hosts = ",".join(temp)
			results = alluc.search(query, hosts, FILTER_LANG)
		else:
			results = alluc.search(query, lang=FILTER_LANG)
	if SORT_BY_HOST:
		from operator import itemgetter
		results.sort(key=itemgetter('host'))
		if DB_TYPE == 'sqlite':
			DB.execute("INSERT INTO fetch_count(num) select ifnull(sum(num),0) + ? from fetch_count where ts=DATE('now')", [len(results)])
		else:
			DB.execute("REPLACE INTO fetch_count(num,ts) SELECT IF(ISNULL(SUM(num)),0,num)+?, NOW() FROM fetch_count WHERE ts=DATE(NOW())", [len(results)])
	dialog = xbmcgui.Dialog()
	streams = []
	options = []
	if args['mode']=='watch_episode' and SMART_FILTER:
		s=args['season']
		ss=args['season'].zfill(2)
		e=args['episode'].zfill(2)				
		patern = "(S%sE%s)|(%s%s)|(%s.%s)|(%s.%s)" % (ss,e,s,e,ss,e,s,e)
		test = re.compile(patern, re.IGNORECASE)
	for result in results:
		if args['mode']=='watch_episode' and SMART_FILTER:
			if test.search(result['title']):
				streams.append(result['title'])
				options.append(result['url'])
				if CACHE_RESULTS and cached_results is not True:
					DB.execute("INSERT INTO search_cache(hash_id, display, url, host) VALUES(?,?,?,?)", [hash_id, result['title'], result['url'], result['host']])
		else:
			streams.append(result['title'])
			options.append(result['url'])
			if CACHE_RESULTS and cached_results is not True:
				DB.execute("INSERT INTO search_cache(hash_id, display, url, host) VALUES(?,?,?,?)", [hash_id, result['title'], result['url'], result['host']])

	if ADDON.get_bool_setting('enable-furk'):
		from furk_api import FurkAPI
		furk = FurkAPI(ADDON.get_setting('furk-username'), ADDON.get_setting('furk-password'), ADDON.get_setting('furk-apikey'))
		furk_links = furk.search(query)
		for result in furk_links:
			if args['mode']=='watch_episode' and SMART_FILTER:
				if test.search(result['title']):
					streams.append(result['title'])
					options.append(result['url'])
					if CACHE_RESULTS and cached_results is not True:
						DB.execute("INSERT INTO search_cache(hashid, display, url, host) VALUES(?,?,?, 'furk.net')", [hash_id, result['title'], result['url']])
			else:
				streams.append(result['title'])
				options.append(result['url'])
				if CACHE_RESULTS and cached_results is not True:
					DB.execute("INSERT INTO search_cache(hashid, display, url, host) VALUES(?,?,?, 'furk.net')", [hash_id, result['title'], result['url']])
	if CACHE_RESULTS:
		DB.execute("DELETE FROM search_cache WHERE strftime('%s','now') -  strftime('%s',ts) < (3600 * 4)=0")
	DB.commit()
	if len(results) == 0:
		s=get_str(30841)
		Notify("%s:" % s[0], s[1])
		return False
	stream_select = dialog.select(get_str(30814), streams)
	if stream_select < 0:
		return False
	raw_url = options[stream_select]
	if USE_METADATA:
		MH = metahandlers.MetaData()
		if args['mode']=='watch_episode':
			from trakt_api import TraktAPI
			trakt = TraktAPI()
			metadata = MH.get_episode_meta(args['series'], args['imdb_id'], args['season'], args['episode'])
			metadata['cover_url'] = trakt.get_episode_screenshot(args['imdb_id'], args['season'], args['episode'])
		if args['mode']=='watch_movie':
			metadata = MH.get_meta('movie', args['title'], imdb_id=args['imdb_id'])
	WatchStream(raw_url, metadata)
	
def DoSearch(title):
	kb = xbmc.Keyboard('', title, False)
	kb.doModal()
	if (kb.isConfirmed()):
		search = kb.getText()
		if search != '':
			return search
	return False

def DoSelect(title, texts=[], options=[]):
	dialog = xbmcgui.Dialog()
	select = dialog.select(title, texts)
	if select < 0:
		return False
	result = options[select]
	return result

def WatchEpisode(args):
	s = str(args['season'])
	e = str(args['episode'])
	query = "%s S%sE%s" % (args['series'], s.zfill(2), e.zfill(2))
	AllucSearch(query)

def WatchMovie(title, year):
	query = "%s %s" % (title, year)
	AllucSearch(query)

def LaunchStream():
	if args['media'] == 'episode':
		from trakt_api import TraktAPI
		trakt = TraktAPI()
		show = trakt.get_show_info(args['imdb_id'])
		args['series'] = show['title']
		args['mode'] = 'watch_episode'
		episodeid = get_episodeid(args['series'], args["season"], args["episode"])
		if episodeid:
			resume = DB.query("SELECT current, total FROM player_state WHERE media='episode' AND video_id=?", [episodeid])
			if resume:
				display = "%s (%sx%s)" % (args['series'],args['season'],args['episode'])
				if confirm_resume(display, float(resume[0])):
					args['resume'] = resume
		WatchEpisode(args)
	elif args['media'] == 'movie':
		from trakt_api import TraktAPI
		trakt = TraktAPI()
		movie = trakt.get_movie_info(args['imdb_id'])
		args['mode']='watch_movie'
		args['title'] = movie['title']
		movieid = get_movieid(movie['title'], movie['year'])
		if movieid:
			resume = DB.query("SELECT current, total FROM player_state WHERE media='movie' AND video_id=?", [movieid])
			if resume:
				if confirm_resume(movie['title'], float(resume[0])):
					args['resume'] = resume
		WatchMovie(movie['title'], movie['year'])

def confirm_resume(title, position):
	minutes, seconds = divmod(position, 60)
	if minutes > 60:
		hours, minutes = divmod(minutes, 60)
		t = "%02d:%02d:%02d" % (hours, minutes, seconds)
	else:
		t = "%02d:%02d" % (minutes, seconds)
	s = get_str(30845)
	return DoSelect(s[0], ['%s %s' % (s[1],t), s[2]], [True, False])	

def WatchStream(raw_url, metadata={"cover_url": ''}):
	if re.match('^furk://', raw_url):
		from furk_api import FurkAPI
		furk = FurkAPI(ADDON.get_setting('furk-username'), ADDON.get_setting('furk-password'), ADDON.get_setting('furk-apikey'))
		resolved_url = furk.resolve_url(raw_url)
		print resolved_url
	else:
		import urlresolver
		source = urlresolver.HostedMediaFile(url=raw_url)
		resolved_url = source.resolve() if source else None
	if resolved_url is not None:
		StreamFile(resolved_url, metadata)
	else:
		s = get_str(30815)
		Notify("%s:" % s[0], s[1])
		print "Failed to resolve: %s" % raw_url

def StreamFile(url, metadata={"cover_url": ''}):
	if re.match('interfaces.unresolvable', str(url)):
		s = get_str(30816)
		Notify("%s:" % s[0], s[1])
		return False
	try:
		listitem = xbmcgui.ListItem('video', iconImage=metadata['cover_url'], thumbnailImage=metadata['cover_url'], path=url)
		listitem.setProperty('IsPlayable', 'true')
		if 'resume' in args.keys():
			listitem.setProperty('ResumeTime', str(args['resume'][0]))
			listitem.setProperty('Totaltime', str(args['resume'][1]))
		listitem.setPath(url)
		listitem.setInfo('video', metadata)
	except Exception, e:
		return False
	win = xbmcgui.Window(10000)
	win.setProperty(WINDOW_PREFIX+'.playing', 'True')
	win.setProperty(WINDOW_PREFIX+'.metadata', json.dumps(metadata))
	PlayFile(listitem, url)
		
def PlayFile(listitem, url):
	try:
		xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem)
	except Exception, e:
		ADDON.log( e )

def ShowCutsomLists(media):
	from trakt_api import TraktAPI
	trakt = TraktAPI()
	lists = trakt.get_custom_lists()
	MENU_ITEM({'mode': 'create_custom_list', "media": media}, {"title": '***'+get_str(30734)+'***'}, image=ART_PATH+'/create_trakt_list.jpg')
	sync_list = DB.query("SELECT id, slug, sync FROM lists", force_double_array=True)
	for list in lists:
		is_sync = False
		for li in sync_list:
			if li[2] == 1 and li[1]==list['ids']['slug']:
				is_sync = True
				break
		Ct = ContextMenu()
		if is_sync:
			display = "[COLOR %s]%s[/COLOR]" % (ENABLED_COLOR, list['name'])
			Ct.add(get_str(30740), {"mode": "unsync_%s_library" % media, 'slug': list['ids']['slug'], "media": media, "title": list['name']}, require_auth=True)
		else:
			display = list['name']
			Ct.add(get_str(30729), {"mode": "sync_%s_library" % media, 'slug': list['ids']['slug'], "media": media, "title": list['name']}, require_auth=True)
		Ct.add(get_str(30735), {"mode": "delete_custom_list", 'slug': list['ids']['slug'], "media": media, "title": list['name']}, require_auth=True)
		MENU_ITEM({'mode': media+'_custom_list', 'slug': list['ids']['slug'], "media": media}, {"title": display}, image=ART_PATH+'/trakt_list.jpg', menu=Ct)
	EOD('default-list-view')

def CreateCustomList():
	title = DoSearch(get_str(30737))
	if title:
		from trakt_api import TraktAPI
		trakt = TraktAPI()
		lists = trakt.create_custom_list(title)
		Notify("%s:" % get_str(30817), title)
		REFRESH()

def DeleteCustomList(slug, title):
	s = get_str(30818)
	ok = Confirm(s[0], "%s?" %s[1], title)
	if ok:
		from trakt_api import TraktAPI
		trakt = TraktAPI()
		trakt.delete_custom_list(slug)
		Notify("%s:" % get_str(30819), title)
		REFRESH()

def AddToCustomList(media, imdb_id, title):
	from trakt_api import TraktAPI
	trakt = TraktAPI()
	lists = trakt.get_custom_lists()
	selects = []
	options = []
	for li in lists:
		selects.append(li['name'])
		options.append(li['ids']['slug'])
	slug = DoSelect(get_str(30820), selects, options)
	trakt.add_to_custom_list(media, slug, imdb_id)
	Notify("%s:" % get_str(30821), title)

def RemoveFromCustomList(media, slug, imdb_id, title):
	s=get_str(30822)
	ok = Confirm(s[1], "%s?" % s[1], title)
	if ok:
		from trakt_api import TraktAPI
		trakt = TraktAPI()
		trakt.delete_from_custom_list(media, slug, imdb_id)
		Notify("%s:" % get_str(30823), title)
		REFRESH()

def MovieGenres():
	genre = getKeyVal(args, 'genre')
	if genre is None:
		genres = ["Action", "Adventure", "Animation", "Comedies", "Crime", "Documentaries", "Drama", "Family", "Fantasy", "History", "Horror", "Mystery", "Romance", "Thrillers", "Westerns"]
		local_genres = get_str(30743)
		for genre in genres:
			display = local_genres[genres.index(genre)]
			MENU_ITEM({'mode': 'movie_genres', "genre": genre}, {'title': display}, image=ART_PATH+'/'+genre+'.jpg')
		EOD('default-list-view')
	else:
		MovieList('movie_genres', genre=genre)
		
def MovieList(mode, genre=None):
	from trakt_api import TraktAPI
	trakt = TraktAPI()
	if mode == 'movie_trending':
		movies = trakt.get_trending_movies()
	elif mode == 'movie_popular':
		movies = trakt.get_popular_movies()
	elif mode == 'movie_recommended':
		movies = trakt.get_recommended_movies()
	elif mode == 'movie_search':
		query = DoSearch(get_str(30824))
		if query is False: return
		movies = trakt.search(query, 'movie')
	elif mode == 'movie_custom_list':
		movies = trakt.get_custom_list(args['slug'], 'movie')
	elif mode == 'movie_watchlist':
		movies = trakt.get_watchlist_movies(DB)
	elif mode == 'movie_genres':
		if 'start' in args.keys():
			start = int(args['start'])
		else:
			start = 0
		print genre
		from imdb_api import IMDB
		imdb = IMDB()
		movies = imdb.get_genre_list(genre, media='movies', start=start)
	favorites = DB.query("SELECT imdb_id FROM favorites WHERE media='MOVIE'", force_double_array=True)
	NextMarker=False
	if len(movies) > 0:
		if genre is not None:
			if 'start' in movies[0].keys():
				MENU_ITEM({'mode': 'movie_genres', "genre": genre, "start": movies[0]['start']}, {'title': "[COLOR %s]<< %s[/COLOR]" % (EXTENSION_COLOR, get_str(30744))})
				movies.pop(0)
			if 'start' in movies[len(movies)-1].keys():
				NextMarker=movies[len(movies)-1]['start']
				movies.pop()
		PB.new(get_str(30825), len(movies))
		if USE_METADATA and NUMBER_THREADS > 1:
			from threadpool import ThreadPool
			pool = ThreadPool(NUMBER_THREADS)
			completed = []
			def complete_task(data):
				completed.append(data)
			def lookup_task(data):
				if (PB.iscanceled()): return
				MH = metahandlers.MetaData()
				metadata = MH.get_meta('movie', normalize(data['title']), imdb_id=data['imdb_id'])
				return [data, metadata]
			for movie in movies:
				if (PB.iscanceled()): return
				pool.queueTask(lookup_task, movie, complete_task)
			pool.joinAll()
			completed.sort(key=lambda x: x[0]['title'])
			for row in completed:
				if (PB.iscanceled()): return
				add_movie_row(row[0], row[1], favorites)
		elif USE_METADATA and NUMBER_THREADS == 1:
			MH = metahandlers.MetaData()
			movies.sort(key=lambda x: x['title'])
			for movie in movies:
				if (PB.iscanceled()): return
				metadata = MH.get_meta('movie', normalize(movie['title']), imdb_id=movie['imdb_id'])
				add_movie_row(movie, metadata, favorites)
		else:
			movies.sort(key=lambda x: x['display'])
			for movie in movies:
				if (PB.iscanceled()): return
				metadata = {'title': movie['display'], "poster": "", "fanart": ""}
				add_movie_row(movie, metadata, favorites)
		PB.close()
	if NextMarker:
		MENU_ITEM({'mode': 'movie_genres', "genre": genre, "start": NextMarker}, {'title': "[COLOR %s]%s >>[/COLOR]" % (EXTENSION_COLOR, get_str(30745))})
	EOD('default-movie-view', 'movies')

def add_movie_row(movie, metadata, favorites):
	Ct = ContextMenu()
	PB.next(movie['display'])
	imdb_id = movie['imdb_id']
	title = movie['title']
	display = movie['display']
	if movie['fanart']:
		fanart = movie['fanart']
	else:
		fanart = metadata['backdrop_url']
	if movie['poster']:
		poster = movie['poster']
	else:
		poster = metadata['cover_url']
	year = movie['year']
	metadata['title'] = display	
	is_fav = False
	for test in favorites:
		if test[0]==imdb_id:
			is_fav = True
			break
	if ADVANCED_MODE:
		Ct.add(get_str(30722), {"mode": "add_movie_library", "imdb_id": imdb_id, "title": title})
	if args['mode'] == 'movie_custom_list':
		Ct.add(get_str(30739), {"mode": "remove_from_custom_list", "imdb_id": imdb_id, "title": title, "media": "MOVIE", "slug": args['slug']}, require_auth=True)
	else:
		Ct.add(get_str(30738), {"mode": "add_to_custom_list", "imdb_id": imdb_id, "title": title, "media": "MOVIE"}, require_auth=True)
	if is_fav:
		if args['mode'] != 'movie_watchlist':
			metadata['title'] = "[COLOR %s]%s[/COLOR]" % (ENABLED_COLOR, display)
		Ct.add(get_str(30724), {"mode": "remove_favorite", "media": "MOVIE", "imdb_id": imdb_id, "title": title}, require_auth=True)
		MENU_ITEM({'mode': 'watch_movie', 'imdb_id': imdb_id, "fanart": fanart, 'title': title, 'year': year}, metadata, image=poster, fanart=fanart, menu=Ct,isPlayable=True)
	else:
		Ct.add(get_str(30723), {"mode": "add_favorites", "media": "MOVIE", "imdb_id": imdb_id, "title": title}, require_auth=True)
		MENU_ITEM({'mode': 'watch_movie', 'imdb_id': imdb_id, "fanart": fanart, 'title': title, 'year': year}, metadata, image=poster, fanart=fanart, menu=Ct,isPlayable=True)

def TVGenres():
	genre = getKeyVal(args, 'genre')
	if genre is None:
		genres = ["Action", "Adventure", "Animation", "Comedies", "Crime", "Documentaries", "Drama", "Family", "Fantasy", "History", "Horror", "Mystery", "Romance", "Thrillers", "Westerns"]
		local_genres = get_str(30743)
		for genre in genres:
			display = local_genres[genres.index(genre)]
			MENU_ITEM({'mode': 'tv_genres', "genre": genre}, {'title': display}, image=ART_PATH+'/'+genre+'.jpg')
		EOD('default-list-view')
	else:
		TVList('tv_genres', genre=genre)
	

def TVList(mode, genre=None):
	from trakt_api import TraktAPI
	trakt = TraktAPI()	
	if mode == 'tv_trending':
		shows = trakt.get_trending_shows()
	elif mode == 'tv_popular':
		shows = trakt.get_popular_shows()
	elif mode == 'tv_recommended':
		shows = trakt.get_recommended_shows()
	elif mode == 'tv_search':
		query = DoSearch(get_str(30824))
		if query is False: return
		shows = trakt.search(query, 'show')
	elif mode == 'tv_watchlist':
		shows = trakt.get_watchlist_shows(DB)
	elif mode == 'tvshow_custom_list':
		shows = trakt.get_custom_list(args['slug'], 'tvshow')
	elif mode == 'tv_genres':
		if 'start' in args.keys():
			start = int(args['start'])
		else:
			start = 0
		print genre
		from imdb_api import IMDB
		imdb = IMDB()
		shows = imdb.get_genre_list(genre,media='tvshows', start=start)
	favorites = DB.query("SELECT imdb_id FROM favorites WHERE media='TV'", force_double_array=True)
	NextMarker=False
	if len(shows) > 0:
		if genre is not None:
			if 'start' in shows[0].keys():
				MENU_ITEM({'mode': 'tv_genres', "genre": genre, "start": shows[0]['start']}, {'title': "[COLOR %s]<< %s[/COLOR]" % (EXTENSION_COLOR, get_str(30744))})
				shows.pop(0)
			if 'start' in shows[len(shows)-1].keys():
				NextMarker=shows[len(shows)-1]['start']
				shows.pop()
		PB.new(get_str(30826), len(shows))
		if USE_METADATA and NUMBER_THREADS > 1:
			from threadpool import ThreadPool
			pool = ThreadPool(NUMBER_THREADS)
			completed = []
			def complete_task(data):
				completed.append(data)
			def lookup_task(data):
				if (PB.iscanceled()): return
				MH = metahandlers.MetaData()
				metadata = MH.get_meta('tvshow', normalize(data['title']), imdb_id=data['imdb_id'])
				return [data, metadata]
			for show in shows:
				pool.queueTask(lookup_task, show, complete_task)
			pool.joinAll()
			completed.sort(key=lambda x: x[0]['title'])
			for row in completed:
				if (PB.iscanceled()): return
				add_tvshow_row(row[0], row[1], favorites)
		elif USE_METADATA and NUMBER_THREADS == 1:
			MH = metahandlers.MetaData()
			shows.sort(key=lambda x: x['title'])
			for show in shows:
				if (PB.iscanceled()): return
				metadata = MH.get_meta('tvshow', normalize(show['title']), imdb_id=show['imdb_id'])
				add_tvshow_row(show, metadata, favorites)
		else:
			shows.sort(key=lambda x: x['display'])
			for show in shows:
				if (PB.iscanceled()): return
				metadata = {'title': show['display'], "poster": "", "fanart": ""}
				add_tvshow_row(show, metadata, favorites)
		PB.close()
	if NextMarker:
		MENU_ITEM({'mode': 'tv_genres', "genre": genre, "start": NextMarker}, {'title': "[COLOR %s]%s >>[/COLOR]" % (EXTENSION_COLOR, get_str(30745))})
	EOD('default-tvshow-view', 'tvshows')

def add_tvshow_row(show, metadata, favorites):
	PB.next(show['display'])
	Ct = ContextMenu()
	imdb_id = show['imdb_id']
	title = show['title']
	display = show['display']
	year = show['year']
	if show['fanart']:
		fanart = show['fanart']
	else:
		fanart = metadata['backdrop_url']
	if show['poster']:
		poster = show['poster']
	else:
		poster = metadata['cover_url']
	metadata['title'] = display
	is_fav = False
	for test in favorites:
		if test[0]==imdb_id:
			is_fav = True
			break
	if ADVANCED_MODE:
		Ct.add(get_str(30804), {"mode": "tv_subscribe", "imdb_id": imdb_id, "title": title})
	if args['mode'] == 'tv_custom_list':
		Ct.add(get_str(30739), {"mode": "remove_from_custom_list", "imdb_id": imdb_id, "title": title, "media": "TV", "slug": args['slug']}, require_auth=True)
	else:
		Ct.add(get_str(30738), {"mode": "add_to_custom_list", "imdb_id": imdb_id, "title": title, "media": "TV"}, require_auth=True)
	if is_fav:
		if args['mode'] != 'tv_watchlist':
			metadata['title'] = "[COLOR %s]%s[/COLOR]" % (ENABLED_COLOR, display)
		Ct.add(get_str(30724), {"mode": "remove_favorite", "media": "TV", "imdb_id": imdb_id, "title": title}, require_auth=True)
		MENU_ITEM({'mode': 'tv_seasons', 'imdb_id': imdb_id, "fanart": fanart, 'series': title}, metadata, image=poster, fanart=fanart, menu=Ct)
	else:
		Ct.add(get_str(30723), {"mode": "add_favorites", "media": "TV", "imdb_id": imdb_id, "title": title}, require_auth=True)
		MENU_ITEM({'mode': 'tv_seasons', 'imdb_id': imdb_id, "fanart": fanart, 'series': title}, metadata, image=poster, fanart=fanart, menu=Ct)


def MyCalendar():
	from trakt_api import TraktAPI
	trakt = TraktAPI()
	episodes = trakt.get_calendar_shows()
	if len(episodes) > 0:
		PB.new(get_str(30827), len(episodes))
		if USE_METADATA and NUMBER_THREADS > 1:
			from threadpool import ThreadPool
			pool = ThreadPool(NUMBER_THREADS)
			completed = []
			def complete_task(data):
				completed.append(data)
			def lookup_task(data):
				if (PB.iscanceled()): return
				MH = metahandlers.MetaData()
				metadata = MH.get_episode_meta(normalize(data['title']), data['imdb_id'], data['season'], data['episode'])
				return [data, metadata]
			for episode in episodes:
				pool.queueTask(lookup_task, episode, complete_task)
			pool.joinAll()
			completed.sort(key=lambda x: x[0]['aired'])
			for row in completed:
				if (PB.iscanceled()): return
				add_calendar_row(row[0], row[1])
		elif USE_METADATA and NUMBER_THREADS==1:
			MH = metahandlers.MetaData()
			episodes.sort(key=lambda x: x['aired'])
			for episode in episodes:
				if (PB.iscanceled()): return
				metadata = MH.get_episode_meta(normalize(episode['title']), episode['imdb_id'], episode['season'], episode['episode'])
				add_calendar_row(episode, metadata)
		else:
			episodes.sort(key=lambda x: x['aired'])
			for episode in episodes:
				if (PB.iscanceled()): return
				metadata = {'title': episode['display']}
				add_calendar_row(episode, metadata)
		PB.close()
	EOD('default-episode-view', 'episodes')

def add_calendar_row(row, metadata):
	Ct = ContextMenu()
	PB.next(row['display'])
	series = row['series']
	imdb_id = row['imdb_id']
	poster = row['poster']
	fanart = row['fanart']
	episode = str(row['episode'])
	season = str(row['season'])
	metadata['title'] = row['display']
	Ct.add(get_str(30851), {'mode': 'tv_seasons', 'imdb_id': imdb_id, "fanart": fanart, 'series': series})
	if getKeyVal(metadata, 'overlay')==7:
		Ct.add(get_str(30726), {'mode': 'mark_unwatched', 'media': 'episode', 'title': series, 'imdb': imdb_id, 'season': season, 'episode': episode})
	else:
		Ct.add(get_str(30725), {'mode': 'mark_watched', 'media': 'episode', 'title': series, 'imdb': imdb_id, 'season': season, 'episode': episode})
	MENU_ITEM({'mode': 'watch_episode', 'imdb_id': imdb_id, 'season': season, 'episode': episode, 'series': series}, metadata, image=poster, fanart=fanart, menu=Ct, isPlayable=True)
	
def TVListSeasons(imdb_id, series='', fanart=""):
	from trakt_api import TraktAPI
	trakt = TraktAPI()	
	seasons = trakt.get_show_seasons(imdb_id)
	for season in seasons:
		n = str(season['number'])
		if n != "0":
			image = season['images']['poster']['full']
			MENU_ITEM({'mode': 'tv_episodes', 'imdb_id': imdb_id, 'season': n, "fanart": fanart, "series": series}, {'title': "Season " + n}, image=image, fanart=fanart)
	EOD('default-season-view', 'tvshows')

def TVListEpisodes(imdb_id, season, series='', fanart=""):
	from datetime import datetime, date
	today = date.today()
	from trakt_api import TraktAPI
	trakt = TraktAPI()
	episodes = trakt.get_show_episodes(imdb_id, season)
	if len(episodes) > 0:
		PB.new(get_str(30827), len(episodes))
		if USE_METADATA and NUMBER_THREADS > 1:
			from threadpool import ThreadPool
			pool = ThreadPool(NUMBER_THREADS)
			completed = []
			def complete_task(data):
				completed.append(data)
			def lookup_task(data):
				if (PB.iscanceled()): return
				MH = metahandlers.MetaData()
				data['imdb_id'] = imdb_id
				data['series'] = series
				data['fanart'] = fanart
				metadata = MH.get_episode_meta(normalize(data['title']), data['imdb_id'], data['season'], data['episode'])
				return [data, metadata]
			for episode in episodes:
				if (PB.iscanceled()): return
				pool.queueTask(lookup_task, episode, complete_task)
			pool.joinAll()
			completed.sort(key=lambda x: x[0]['aired'])
			for row in completed:
				add_episode_row(row[0], row[1])
		elif USE_METADATA and NUMBER_THREADS == 1:
			MH = metahandlers.MetaData()
			episodes.sort(key=lambda x: x['aired'])
			for episode in episodes:
				if (PB.iscanceled()): return
				episode['imdb_id'] = imdb_id
				episode['series'] = series
				episode['fanart'] = fanart
				metadata = MH.get_episode_meta(normalize(episode['title']), episode['imdb_id'], episode['season'], episode['episode'])
				add_episode_row(episode, metadata)
		else:
			episodes.sort(key=lambda x: x['aired'])
			for episode in episodes:
				if (PB.iscanceled()): return
				episode['imdb_id'] = imdb_id
				episode['series'] = series
				episode['fanart'] = fanart
				metadata = {'title': episode['display']}
				add_episode_row(episode, metadata)
		PB.close()
	EOD('default-episode-view', 'tvshows')

def add_episode_row(row, metadata):
	PB.next(row['display'])
	series = row['series']
	imdb_id = row['imdb_id']
	poster = row['poster']
	fanart = row['fanart']
	episode = str(row['episode'])
	season = str(row['season'])
	metadata['title'] = row['display']
	Ct = ContextMenu()
	if getKeyVal(metadata, 'overlay')==7:
		Ct.add(get_str(30726), {'mode': 'mark_unwatched', 'media': 'episode', 'title': series, 'imdb': imdb_id, 'season': season, 'episode': episode})
	else:
		Ct.add(get_str(30725), {'mode': 'mark_watched', 'media': 'episode', 'title': series, 'imdb': imdb_id, 'season': season, 'episode': episode})
	MENU_ITEM({'mode': 'watch_episode', 'imdb_id': imdb_id, 'season': season, 'episode': episode, 'series': series},metadata, image=poster, fanart=fanart, menu=Ct, isPlayable=True)
		
############################
### Menus		         ###
############################

def MainMenu():
	ADDON.log("main menu")
	MENU_ITEM({'mode': 'tv_menu'}, {'title': get_str(30700)}, image=ART_PATH+'/tvshows.jpg')
	MENU_ITEM({'mode': 'movie_menu'}, {'title': get_str(30701)}, image=ART_PATH+'/movies.jpg')
	MENU_ITEM({'mode': 'set_language'}, {'title': get_str(30702)}, image=ART_PATH+'/languages.jpg')
	MENU_ITEM({'mode': 'quick_search'}, {'title': get_str(30703)}, image=ART_PATH+'/search_quick.jpg')
	MENU_ITEM({'mode': 'settings'}, {'title': get_str(30704)}, image=ART_PATH+'/settings_alluc.jpg')
	if ADVANCED_MODE:
		MENU_ITEM({'mode': 'autoupdate_all'}, {'title': get_str(30736)}, image=ART_PATH+'/update_now.jpg')
	MENU_ITEM({'mode': 'show_help'}, {'title': get_str(30741)}, image=ART_PATH+'/help.jpg')
	EOD()
	
def TVMenu():
	ADDON.log("tv menu")
	MENU_ITEM({'mode': 'tv_calendar'}, {'title': get_str(30705)}, image=ART_PATH+'/calendar.jpg', require_auth=True)
	MENU_ITEM({'mode': 'tv_watchlist'}, {'title': get_str(30706)}, image=ART_PATH+'/watchlist.jpg', require_auth=True)
	MENU_ITEM({'mode': 'tv_custom_lists'}, {'title': get_str(30730)}, image=ART_PATH+'/custom_list.jpg', require_auth=True)
	#MENU_ITEM({'mode': 'tv_genres'}, {'title': get_str(30742)}, image=ART_PATH+'/genres.jpg')
	MENU_ITEM({'mode': 'tv_recommended'}, {'title': get_str(30707)}, image=ART_PATH+'/recommended.jpg', require_auth=True)
	MENU_ITEM({'mode': 'tv_popular'}, {'title': get_str(30708)}, image=ART_PATH+'/popular.jpg')
	MENU_ITEM({'mode': 'tv_trending'}, {'title': get_str(30709)}, image=ART_PATH+'/trending.jpg')
	MENU_ITEM({'mode': 'tv_search'}, {'title': get_str(30710)}, image=ART_PATH+'/search.jpg')
	EOD()
	
def MovieMenu():
	ADDON.log("movie menu")
	MENU_ITEM({'mode': 'movie_watchlist'}, {'title': get_str(30711)}, image=ART_PATH+'/watchlist.jpg', require_auth=True)
	MENU_ITEM({'mode': 'movie_custom_lists'}, {'title': get_str(30712)}, image=ART_PATH+'/custom_list.jpg', require_auth=True)
	#MENU_ITEM({'mode': 'movie_genres'}, {'title': get_str(30742)}, image=ART_PATH+'/genres.jpg')
	MENU_ITEM({'mode': 'movie_recommended'}, {'title': get_str(30713)}, image=ART_PATH+'/recommended.jpg', require_auth=True)
	MENU_ITEM({'mode': 'movie_popular'}, {'title': get_str(30714)}, image=ART_PATH+'/popular.jpg')
	MENU_ITEM({'mode': 'movie_trending'}, {'title': get_str(30715)}, image=ART_PATH+'/trending.jpg')
	MENU_ITEM({'mode': 'movie_search'}, {'title': get_str(30716)}, image=ART_PATH+'/search.jpg')
	EOD()
	
def SettingsMenu():
	ADDON.log("settings menu")
	if ADVANCED_MODE:
		MENU_ITEM({'mode': 'add_source_folders'}, {'title': get_str(30727)}, image=ART_PATH+'/add_source_folders.jpg')
		MENU_ITEM({'mode': 'manage_subscriptions'}, {'title': get_str(30717)}, image=ART_PATH+'/subscriptions.jpg')
	if FILTER_RESULTS:
		MENU_ITEM({'mode': 'manage_hostlist'}, {'title': get_str(30728)}, image=ART_PATH+'/hoster_list.jpg')
	MENU_ITEM({'mode': 'alluc_settings'}, {'title': get_str(30704)}, image=ART_PATH+'/settings_alluc.jpg')
	MENU_ITEM({'mode': 'urlresolver_settings'}, {'title': get_str(30718)}, image=ART_PATH+'/urlresolver.jpg')
	MENU_ITEM({'mode': 'metahandler_settings'}, {'title': get_str(30719)}, image=ART_PATH+'/metahandler.jpg')
	MENU_ITEM({'mode': 'reset_alluc'}, {'title': get_str(30746)}, image=ART_PATH+'/reset.jpg')
	EOD()
############################
### Modes		         ###
############################

args = ADDON.parse_query(sys.argv[2])
ADDON.log(args)
#if args['mode'] not in 		['import_keyfile']:
#	VersonCheck()
#Main Menu
if args['mode'] == 			'main':
	VersonCheck()
	MainMenu()
elif args['mode'] == 		'tv_menu':
	TVMenu()
elif args['mode'] == 		'quick_search':
	AllucSearch()
elif args['mode'] == 		'movie_menu':
	MovieMenu()	
elif args['mode'] == 		'set_language':
	SelectLanguage()
elif args['mode'] == 		'settings':
	SettingsMenu()
elif args['mode'] == 		'run_setup':
	xbmc.executebuiltin('RunScript("plugin.video.alluc.api", "")')
elif args['mode'] == 		'show_help':
	ShowInstructions()
	
#TV Menus
elif args['mode'] in 		['tv_trending', 'tv_recommended', 'tv_popular', 'tv_watchlist', 'tv_search', 'tvshow_custom_list']:
	TVList(args['mode'])
elif args['mode'] == 		'tv_calendar':
	MyCalendar()
elif args['mode'] == 		'tv_seasons':
	TVListSeasons(args['imdb_id'], args['series'], args['fanart'])
elif args['mode'] == 		'tv_episodes':
	TVListEpisodes(args['imdb_id'], args['season'], args['series'], args['fanart'])
elif args['mode'] == 		'tv_custom_lists':
	ShowCutsomLists('tvshow')	
elif args['mode'] == 		'tv_genres':
	TVGenres()
	
#Movie Menus
elif args['mode'] in 		['movie_trending', 'movie_recommended', 'movie_popular', 'movie_watchlist', 'movie_search', 'movie_custom_list']:
	MovieList(args['mode'])
elif args['mode'] == 		'movie_custom_lists':
	ShowCutsomLists('movie')
elif args['mode'] == 		'movie_genres':
	MovieGenres()	

#Settings Menu
elif args['mode'] == 	'alluc_settings':
	xbmcaddon.Addon(id=ADDON_ID).openSettings()
elif args['mode'] == 	'urlresolver_settings':
	xbmcaddon.Addon(id='script.module.urlresolver').openSettings()
elif args['mode'] == 	'metahandler_settings':
	xbmcaddon.Addon(id='script.module.metahandler').openSettings()
elif args['mode'] == 	'add_source_folders':
	SetupLibrary()
elif args['mode'] == 		'manage_subscriptions':
	ListSubscriptions()	
elif args['mode'] == 		'manage_hostlist':
	ManageHostList()
elif args['mode'] == 		'reset_alluc':
	ResetAlluc()
			
#Update Functions
elif args['mode'] == 		'update_subscription':
	UpdateSubscription(args['imdb_id'])
elif args['mode'] == 		'autoupdate_tv':
	Autoupdate('TV', quiet=True)
elif args['mode'] == 		'autoupdate_movie':
	Autoupdate('MOVIE', quiet=True)
elif args['mode'] == 		'autoupdate_library':
	Autoupdate('LIBRARY')
elif args['mode'] == 		'autoupdate_all':
	Autoupdate('TV', quiet=False)
	Autoupdate('MOVIE', quiet=False)	

#Stream Functions
elif args['mode'] ==		'watch_episode':
	WatchEpisode(args)
elif args['mode'] ==		'watch_movie':
	WatchMovie(args['title'], args['year'])
elif args['mode'] ==		'watch_stream':
	LaunchStream()

#Misc Functions
elif args['mode'] in 		['mark_watched', 'mark_unwatched']:
	ToggleWatchedState()
elif args['mode'] ==		'service_mark_watched':
	SetPlayCount(args, 1)
elif args['mode'] == 		'service_save_resume':
	SetResumePoint(args)
elif args['mode'] == 		'add_movie_library':
	AddMovieToLibrary(args['imdb_id'])
elif args['mode'] ==		'add_favorites':
	AddFavorite(args['media'], args['title'], args['imdb_id'])
elif args['mode'] == 		'tv_subscribe':
	Subscribe(args['imdb_id'], args['title'])
elif args['mode'] == 		'tv_unsubscribe':
	Unsubscribe(args['imdb_id'], args['title'])
elif args['mode'] == 		'tv_enable_subscription':
	EnableSubscription(args['imdb_id'])
elif args['mode'] == 		'tv_disable_subscription':
	DisableSubscription(args['imdb_id'])
elif args['mode'] ==		'remove_favorite':
	RemoveFavorite(args['media'], args['title'], args['imdb_id'])
elif args['mode'] ==		'delete_custom_list':
	DeleteCustomList(args['slug'], args['title'])
elif args['mode'] ==		'create_custom_list':
	CreateCustomList()
elif args['mode'] ==		'add_to_custom_list':
	AddToCustomList(args['media'],args['imdb_id'], args['title'])
elif args['mode'] ==		'remove_from_custom_list':
	RemoveFromCustomList(args['media'],args['slug'], args['imdb_id'], args['title'])
elif args['mode'] in 		['sync_movie_library', 'sync_tvshow_library']:
	SyncList(args['title'],args['slug'], args['media'])
elif args['mode'] in 		['unsync_movie_library', 'unsync_tvshow_library']:
	UnSyncList(args['title'], args['slug'])
elif args['mode'] == 		'toggle_host':
	ToggleHost(args['host'])


