#!/usr/bin/python
#Alluc
'''
    Copyright (C) 2015 DudeHere

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

############################
### Imports		 		 ###
############################
import os
import sys
import xbmc
import xbmcaddon
import xbmcgui
sys.path.append(os.path.join(xbmc.translatePath( "special://home/addons/script.module.pyxbmctmanager/" ), 'lib'))
sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'resources', 'lib'))
from commonlib import *
from trakt_api import *
from vfs import VFSClass
vfs = VFSClass()
COOKIE_PATH = vfs.join(DATA_PATH, 'cookies')
CAPTCHA = vfs.join(DATA_PATH, 'puzzle.jpg')
QR_CODE = vfs.join(ROOT_PATH, 'resources/artwork/qr_code.png')
if not vfs.exists(COOKIE_PATH):
	vfs.mkdir(COOKIE_PATH)
COOKIE_JAR = vfs.join(COOKIE_PATH, 'alluc.lpw')
USER_AGENT = 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1500.72 Safari/537.36'
REFERER = 'http://accounts.alluc.com/register.html'
ACCEPT = 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'
WINDOW = xbmcgui.Window(10000)

def normalize(string):
	return unicodedata.normalize('NFKD', unicode(string)).encode('ascii','ignore')

def sys_exit():
	exit = xbmc.executebuiltin("XBMC.ActivateWindow(Home)")
	return exit

def get_str(id):
	local = xbmcaddon.Addon(ADDON_ID).getLocalizedString(id=id)
	local = local.split("||")
	if len(local)==1: return normalize(local[0])
	for i, w in enumerate(local):
		local[i] = normalize(w)
	return local
		
def ResetAlluc():
	from pyxbmctmanager.window import Window
	class ResetWindow(Window):
		def __init__(self, title):
			super(self.__class__,self).__init__(title,width=700, height=300, columns=4, rows=6)
			self.draw()
			
		def set_info_controls(self):
			texts = get_str(30747)
			label = self.create_label(texts[1])
			self.add_label(label, 0, 0, columnspan=4, pad_x=15, pad_y=10)
			
			label = self.create_label(texts[2])
			self.add_label(label, 1, 0, columnspan=4, pad_x=15, pad_y=10)
			
			label = self.create_label(texts[3])
			self.add_label(label, 2, 0, columnspan=4, pad_x=15, pad_y=10)
			
			label = self.create_label(texts[4])
			self.add_label(label, 3, 0, columnspan=4, pad_x=15, pad_y=10)
			
			label = self.create_label(get_str(30748))
			self.add_label(label, 4, 0, columnspan=2, pad_x=15, pad_y=10)
			
			self.create_input('reset')
			self.add_object('reset', 4, 1, columnspan=2)
			
			self.create_button('cancel', 'Cancel')
			self.add_object('cancel',  5, 1)
			
			self.create_button('confirm', 'Reset')
			self.add_object('confirm',  5, 2)
			
		def confirm(self):
			if self.get_value('reset') != 'RESET':
				msg = get_str(30749)
				xbmc.executebuiltin("XBMC.Notification("+msg[0]+","+msg[1]+",1500)")
				return
			dialog = xbmcgui.Dialog()
			msg = get_str(30750)
			ok = dialog.yesno(msg[0], msg[1], msg[2])
			if ok:
				vfs.rm(DATA_PATH, quiet=True, recursive=True)
				self.close()
				sys_exit()
			else:
				self.close()
		
	reset = ResetWindow('%s? Version: %s' % (get_str(30747)[0], VERSION))
	reset.set_object_event('focus', 'reset')
	reset.set_object_event('down', 'reset', 'confirm')
	reset.set_object_event('up', 'confirm', 'reset')
	reset.set_object_event('left', 'confirm', 'cancel')
	reset.set_object_event('right', 'cancel', 'confirm')
	reset.set_object_event('up', 'cancel', 'reset')
	reset.set_object_event('action', 'cancel', reset.close)
	reset.set_object_event('action', 'confirm', reset.confirm)
	reset.show()

def MainSetup():
	from pyxbmctmanager.window import Window
	from pyxbmctmanager.manager import Manager
	class FirstPage(Window):
		def __init__(self, title):
			super(self.__class__,self).__init__(title)
			self.overide_strings = {"next_button": get_str(30857), "previous_button": get_str(30856)} 
		
		def set_info_controls(self):
			try:
				language = xbmc.getLanguage().lower()
			except:
				language = 'english'
			path = vfs.join(ROOT_PATH + '/resources/language/%s' % language, 'welcome.txt', True)
			if vfs.exists(path) is False:
				path = vfs.join(ROOT_PATH + '/resources/language/english', 'welcome.txt', True)
			content  = vfs.read_file(path)
			self.add_label(self.create_label(content), 0, 0, columnspan=4, rowspan=5, pad_x=15, pad_y=10)
			
			self.create_checkbox("show_again", "Don't show again after setup completed", font="font12")
			self.add_object("show_again", 5, 0, columnspan=2)
			self.set_value("show_again", True)
			
	class SecondPage(Window):
		def __init__(self, title):
			super(self.__class__,self).__init__(title, width=800, height=450, columns=4, rows=6)
			self.overide_strings = {"next_button": get_str(30858), "previous_button": get_str(30856)}
		
		def set_info_controls(self):
			path = vfs.join(ROOT_PATH, 'disclosure.txt', True)
			content  = vfs.read_file(path)
			self.add_label(self.create_label(content), 0, 0, columnspan=4, rowspan=5, pad_x=15, pad_y=10)
			
	class ThirdPage(Window):
		def __init__(self, title):
			super(self.__class__,self).__init__(title)
			self.overide_strings = {"next_button": get_str(30857), "previous_button": get_str(30856)}
			def next_action():
				if WM.get_value(2, 'mode_basic'):
					WM.get_object(3, 'use_trakt').setEnabled(False)
				else:
					WM.get_object(3, 'use_trakt').setEnabled(True)
				WM.next_page()
				
			self.overide_actions = {"next_button": next_action}
	
		def set_info_controls(self):
			content = '''
			'''
			try:
				language = xbmc.getLanguage().lower()
			except:
				language = 'english'
			path = vfs.join(ROOT_PATH + '/resources/language/%s' % language, 'modes.txt', True)
			if vfs.exists(path) is False:
				path = vfs.join(ROOT_PATH + '/resources/language/english', 'modes.txt', True)
			content  = vfs.read_file(path)
			self.add_label(self.create_label(content), 0, 0, columnspan=4, rowspan=3, pad_x=15, pad_y=10)
			self.add_label(self.create_label("Select a mode:"), 3, 0, pad_x=15)
			
			def toggle_adv():
				if self.get_value("mode_advanced"):
					self.set_value("mode_basic", False)
				else:
					self.set_value("mode_basic", True)
			
			def toggle_bas():
				if self.get_value("mode_basic"):
					self.set_value("mode_advanced", False)
				else:
					self.set_value("mode_advanced", True)		
			
			self.create_checkbox("mode_basic", "Basic Mode", font="font12")
			self.add_object("mode_basic", 3, 1, columnspan=2)
			self.create_checkbox("mode_advanced", "Advanced Mode", font="font12")
			self.add_object("mode_advanced", 4, 1, columnspan=2)
			if ADDON.get_setting('advanced_mode_1') == 'true':
				self.set_value("mode_basic", False)
				self.set_value("mode_advanced", True)
			else:
				self.set_value("mode_basic", True)
				self.set_value("mode_advanced", False)
			self.set_object_event("action", "mode_basic", toggle_bas)
			self.set_object_event("action", "mode_advanced", toggle_adv)
			
			
	class ForthPage(Window):
		def __init__(self, title):
			super(self.__class__,self).__init__(title)
			self.overide_strings = {"next_button": 'Finish & Save', "previous_button": get_str(30856)} 
			def next_action():
				if self.get_value('use_trakt'): WM.next_page()
				else: SetupComplete()
			self.overide_actions = {"next_button": next_action}
			
		def use_track(self):
			if self.get_value('use_trakt'):
				self.get_object('next_button').setLabel('Next >')
			else:
				self.get_object('next_button').setLabel('Finish & Save')
			
		def set_info_controls(self):
			self.add_label(self.create_label(get_str(30848)), 0, 0, columnspan=4, rowspan=2, pad_x=15, pad_y=10)
			
			self.add_label(self.create_label(get_str(30838)), 2, 0, pad_x=15)
			
			self.create_input('username')
			self.add_object('username', 2, 1, columnspan=2)
			self.set_value('username', ADDON.get_setting('alluc-username'))
			
			self.add_label(self.create_label(get_str(30839)), 3, 0, pad_x=15)
			
			self.create_input('password', isPassword=True)
			self.add_object('password', 3, 1, columnspan=2)
			self.set_value('password', ADDON.get_setting('alluc-password'))
			
			self.create_checkbox("use_trakt", "I want to link my Trakt.tv account!")
			self.add_object('use_trakt', 4, 1, columnspan=2)
			
			self.set_object_event('action', 'use_trakt', self.use_track)	
				
			
	class FifthPage(Window):
		def __init__(self, title):
			super(self.__class__,self).__init__(title, width=800, height=450, columns=4, rows=7)
			self.overide_strings = {"next_button": get_str(30857), "previous_button": get_str(30856)}
	
		def set_info_controls(self):
			self.add_label(self.create_label(get_str(30855) % PIN_URL), 0, 0, columnspan=4, rowspan=2, pad_x=15)
			
			self.create_input('pin')
			self.add_object('pin', 2, 0, columnspan=4)
			
			self.create_button('authorize', get_str(30847))
			self.add_object('authorize', 6, 3)
			
			self.create_image('qr_code', QR_CODE, aspectRatio=2)
			self.add_object('qr_code', 3, 1, columnspan=2, rowspan=3)

	class ConfirmationPage(Window):	
		def set_info_controls(self):
			bg = vfs.join(ROOT_PATH, 'resources/artwork/confirmation.jpg')
			self.create_image('background', bg, aspectRatio=0)
			self.add_object('background', 0, 0, rowspan=6, columnspan=3, pad_x=0, pad_y=0)
			if WM.get_value(3, "use_trakt"):
				text = get_str(30853)
			else:
				text = get_str(30860)
			self.add_label(self.create_label(text, alignment=2, font="font14"), 0, 0, columnspan=3, rowspan=5, pad_x=15, pad_y=15)

			
	WM = Manager()
	WM.add_page(FirstPage('%s Alluc: v%s!' % (get_str(30833), VERSION)))
	WM.add_page(SecondPage('Alluc %s : v%s!' % (get_str(30859), VERSION)))
	WM.add_page(ThirdPage('%s Alluc: v%s!' % (get_str(30833), VERSION)))
	WM.add_page(ForthPage('%s Alluc: v%s!' % (get_str(30833), VERSION)))
	s = get_str(30850)
	WM.add_page(FifthPage('%s - %s!' % (s[0], s[1])))
	WM.add_confirmation(ConfirmationPage(get_str(30852)))
	WM.build()
	WM.set_object_event(0, 'focus', 'next_button')
	WM.set_object_event(0, 'left', 'next_button', 'show_again')
	WM.set_object_event(0, 'right', 'show_again', 'next_button')
	WM.set_object_event(1, 'focus', 'next_button')
	WM.set_object_event(1, 'left', 'next_button', 'previous_button')
	WM.set_object_event(1, 'right', 'previous_button', 'next_button')
	WM.set_object_event(2, 'focus', 'next_button')
	WM.set_object_event(2, 'up', 'next_button', 'mode_advanced')
	WM.set_object_event(2, 'up', 'mode_advanced', 'mode_basic')
	WM.set_object_event(2, 'down', 'mode_basic', 'mode_advanced')
	WM.set_object_event(2, 'down', 'mode_advanced', 'next_button')
	WM.set_object_event(2, 'left', 'next_button', 'previous_button')
	WM.set_object_event(2, 'right', 'previous_button', 'next_button')
	WM.set_object_event(3, 'focus', 'next_button')
	WM.set_object_event(3, 'left', 'next_button', 'previous_button')
	WM.set_object_event(3, 'right', 'previous_button', 'next_button')
	WM.set_object_event(3, 'up', 'previous_button', 'use_trakt')
	WM.set_object_event(3, 'up', 'next_button', 'use_trakt')
	WM.set_object_event(3, 'up', 'previous_button', 'use_trakt')
	WM.set_object_event(3, 'down', 'use_trakt', 'next_button')
	WM.set_object_event(3, 'up', 'use_trakt', 'password')
	WM.set_object_event(3, 'down', 'password', 'use_trakt')
	WM.set_object_event(3, 'up', 'password', 'username')
	WM.set_object_event(3, 'down', 'username', 'password')
	WM.set_object_event(4, 'focus', 'pin')
	WM.set_object_event(4, 'down', 'pin', 'authorize')
	WM.set_object_event(4, 'up', 'authorize', 'pin')
	WM.set_object_event(4, 'up', 'previous_button', 'pin')
	WM.set_object_event(4, 'left', 'authorize', 'previous_button')
	WM.set_object_event(4, 'right', 'previous_button', 'authorize')
	
	
	def SetupComplete():
		username = WM.get_value(3, "username")
		password = WM.get_value(3, "password")
		show_again = WM.get_value(0, "show_again")
		ADDON.set_setting('alluc-username', username)
		ADDON.set_setting('alluc-password', password)
		ADDON.set_setting('setup_run', "true")
		if show_again is False:
			import time
			last_setup_notify = str(time.time())
			ADDON.set_setting('last_setup_notify', last_setup_notify)
		else:
			ADDON.set_setting('last_setup_notify', "true")
	
		if WM.get_value(2, 'mode_basic'):
			mode = "false"
		else:
			mode = "true"
		for i in range(1,8):
			print mode
			key = 'advanced_mode_%s' % i
			print key
			ADDON.set_setting(key, mode)
		authorize = WM.get_value(3, "use_trakt")
		if authorize:
			pin = WM.get_value(4, "pin")
			trakt = TraktAPI()
			response = trakt._authorize(pin)
			if response:
				WM.show_confirmation()
			else:
				s = get_str(30854)
				ADDON.raise_error(s[0], s[1])
		else:
			WM.show_confirmation()
		
	WM.set_object_event(4, "action", "authorize", SetupComplete)		
	WM.show()
	WINDOW.setProperty(WINDOW_PREFIX+'.setup', "false")
	
		
def import_keyfile():
	import xbmcgui, xbmcvfs
	path = xbmcgui.Dialog().browse(1, get_str(30835), "files", "", False )
	fh = xbmcvfs.File(path, 'r')
	content=fh.read().strip()
	fh.close()
	dialog = xbmcgui.Dialog()
	print len(content)
	if len(content)==32:
		s = get_str(30836)
		if dialog.yesno(s[0], "%s?" % s[1], content):
			ADDON.set_setting('alluc-private-key', content)

def color_picker(type):
	import xbmcgui, xbmcvfs
	fh = xbmcvfs.File(ROOT_PATH + '/resources/colors.txt', 'r')
	content=fh.read().strip()
	fh.close()
	colors = content.splitlines()
	dialog = xbmcgui.Dialog()
	display = []
	for color in colors:
		color = color.lower()
		display.append("[COLOR %s]%s[/COLOR]" % (color, color))
	choice = dialog.select(get_str(30837), display)
	if choice < 0:
		return False
	color = colors[choice].lower()
	ADDON.set_setting('custom_color_' + type, color)

def set_language():
	from language import LanguageClass
	import xbmcgui
	lang = LanguageClass()
	dialog = xbmcgui.Dialog()
	choice = dialog.select(get_str(30812), lang.get_languages())
	if choice < 0:
		return False
	choice = lang.get_languages()[choice]
	ADDON.set_setting('filter-lang', choice)	

def download_key():
	from alluc_api import AllucAPI
	AllucAPI()._get_api_key()

args = ADDON.parse_query(sys.argv[2])
print args
if args['mode'] == 		'main':
	MainSetup()
if args['mode'] == 		'reset':
	ResetAlluc()
elif args['mode'] == 		'import_keyfile':
	import_keyfile()
elif args['mode'] == 		'download_key':
	download_key()
elif args['mode'] == 		'color_picker':
	color_picker(args['type'])
elif args['mode'] == 		'set_language':
	set_language()
