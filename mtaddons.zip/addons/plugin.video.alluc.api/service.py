import sys
import os
import time
import urllib
from datetime import datetime, date
import math
import xbmc
import xbmcgui
import xbmcaddon
from metahandler import metahandlers
try: 
	import simplejson as json
except ImportError: 
	import json
sys.path.append(os.path.join(os.path.dirname(os.path.realpath(__file__)), 'resources', 'lib'))

ADDON_ID = 'plugin.video.alluc.api'
ADDON_NAME = 'Alluc'
WINDOW_PREFIX = 'alluc.api'
ADDON = xbmcaddon.Addon(id=ADDON_ID)
ROOT_PATH = xbmc.translatePath(ADDON.getAddonInfo('path'))
DATA_PATH = xbmc.translatePath(ADDON.getAddonInfo('profile'))
PERCENT_MET = 92
def str2bool(v):
	return v.lower() in ("yes", "true", "t", "1")

class AllucService(xbmc.Player):
	def __init__(self, *args, **kwargs):
		xbmc.Player.__init__(self, *args, **kwargs)
		self.win = xbmcgui.Window(10000)
		self.initiated = datetime.now()
		self.delay = 30
		self.timers = {}
		self._clear()

	def log(self, message):
		xbmc.log("%s Service: %s" %(ADDON_NAME, message))

	def get_setting(self, setting):
		return xbmcaddon.Addon(ADDON_ID).getSetting(setting)

	def get_bool_setting(self, setting):
		return  str2bool(xbmcaddon.Addon(ADDON_ID).getSetting(setting))

	def set_setting(self, setting, value):
		return xbmcaddon.Addon(ADDON_ID).setSetting(setting, value)

	def is_enabled(self):
		return self.get_bool_setting('auto_update')

	def set_last_run(self, event, runtime):
		self.set_setting('last-run_'+event,runtime)

	def timestamp(self, d):
		return time.mktime(d.timetuple())
	
	def convert_setting_to_hours(self, t):
		h = 0
		timers = [8, 12, 24]
		h=timers[int(t)]
		return h
	
	def get_next_run(self, f, delay=0):
		seconds =  f * 3600
		delay = delay * 60;
		today = date.today()
		zero = self.timestamp(today)
		now = self.timestamp(datetime.now())
		delta = (now - zero) / (seconds)
		offset = math.ceil(delta)
		next =  offset * seconds + (zero + delay)
		next = datetime.fromtimestamp(next)
		return next
		
	def get_last_run(self, event):
		runtime=self.get_setting('last-run_'+event)
		if runtime:
			try:
				lastrun = datetime.strptime(runtime, '%Y-%m-%d %H:%M:%S.%f')
			except TypeError:
				lastrun = datetime.fromtimestamp(time.mktime(time.strptime(runtime, '%Y-%m-%d %H:%M:%S.%f')))
			return lastrun
		else:
			return self.initiated
	
	def clear_timers(self):
		self.log("Clearing timers...")
		self.set_last_run('tvshows', '')
		self.set_last_run('movies', '')
	
	def load_settings(self):
		self.log("Loading service settings...")
		self.enabled = self.get_bool_setting('auto_update')
		self.update_timer = self.convert_setting_to_hours(self.get_bool_setting('update_timer'))
		self.update_tvshows = self.get_bool_setting('update_tvshows')
		self.update_movies = self.get_bool_setting('update_movies')
		self.update_library = self.get_bool_setting('update_library')
		
	def _db_connect(self):
		if ADDON.getSetting('database_mysql')=='true':
			DB_NAME = ADDON.getSetting('database_mysql_name')
			DB_USER = ADDON.getSetting('database_mysql_user')
			DB_PASS = ADDON.getSetting('database_mysql_pass')
			DB_PORT = ADDON.getSetting('database_mysql_port')
			DB_ADDRESS = ADDON.getSetting('database_mysql_host')
			DB_TYPE = 'mysql'
			from database import MySQLDatabase
			self.DB=MySQLDatabase(DB_ADDRESS, DB_NAME, DB_USER, DB_PASS, DB_PORT)
		else:
			from database import SQLiteDatabase
			DB_TYPE = 'sqlite'
			DB_FILE = xbmc.translatePath(ADDON.getSetting('database_sqlite_file'))
			self.DB=SQLiteDatabase(DB_FILE)
	def _db_close(self):
		self.DB.disconnect()
		
	def _clear(self):
		self.win.clearProperty(WINDOW_PREFIX+'.playing')
		self.win.clearProperty(WINDOW_PREFIX+'.metadata')
		self._total_time = 0
		self._current_time = 0
		self._tracking = False
		self._hashid = ''
	
	def _run_kodi_cmd(self, params):
		cmd = 'RunPlugin(plugin://%s/?%s)' % (ADDON_ID, params)
		xbmc.executebuiltin(cmd)
		
	def onPlayBackStarted(self):
		self._tracking = self.win.getProperty(WINDOW_PREFIX+'.playing') == 'True'
		if self._tracking:
			self.log("Now I'm playing")
			self._total_time = self.getTotalTime()
	
	def onPlayBackStopped(self):
		if self._tracking:
			self.log("Now I'm stopped")
			percent = int(self._current_time * 100 / self._total_time )
			metadata = json.loads(self.win.getProperty(WINDOW_PREFIX+'.metadata'))
			if percent >= PERCENT_MET:
				if 'episode' in metadata.keys():
					params = {'mode': 'service_mark_watched', 'media': 'episode', 'imdb_id': metadata['imdb_id'], 'title': metadata['title'], 'show': metadata["TVShowTitle"], 'season': metadata['season'], 'episode': metadata['episode']}
				else:
					params = {'mode': 'service_mark_watched', 'media': 'movie', 'imdb_id': metadata['imdb_id'], 'title': metadata['title'], 'year': metadata['year']}
				params = urllib.urlencode(params)
				self._run_kodi_cmd(params)	
			else:
				position = self._current_time
				total = self._total_time
				if 'episode' in metadata.keys():
					params = {'mode': 'service_save_resume', 'media': 'episode', 'imdb_id': metadata['imdb_id'], 'title': metadata['title'], 'show': metadata["TVShowTitle"], 'season': metadata['season'], 'episode': metadata['episode'], 'position': position, "total": total, "percent": percent}
				else:
					params = {'mode': 'service_save_resume', 'media': 'movie', 'imdb_id': metadata['imdb_id'], 'title': metadata['title'], 'year': metadata['year'], 'position': position, "total": total, "percent": percent}
				params = urllib.urlencode(params)
				self._run_kodi_cmd(params)
			self._clear()
			
	
	def onPlayBackEnded(self):
		self.onPlayBackStopped()

	def setup_timers(self):
		self.log("Initiating timers...")
		if not self.enabled:
			return
		if self.update_tvshows:
			nextrun = self.get_next_run(self.update_timer)
			self.log("Next tvshow update scheduled to run at %s" % nextrun)
			self.timers['tvshows'] = {}
			self.timers['tvshows']['lastrun'] = self.get_last_run('tvshows')
			self.timers['tvshows']['interval'] = self.update_timer
			self.timers['tvshows']['nextrun'] = nextrun
			self.timers['tvshows']['command'] = 'RunPlugin(plugin://' + ADDON_ID + '/?mode=autoupdate_tv)'	
		else:
			self.timers['tvshows'] = None
	
		if self.update_movies:
			nextrun = self.get_next_run(self.update_timer, delay=5)
			self.log("Next movie update scheduled to run at %s" % nextrun)
			self.timers['movies'] = {}
			self.timers['movies']['lastrun'] = self.get_last_run('movies')
			self.timers['movies']['interval'] = self.update_timer
			self.timers['movies']['nextrun'] = nextrun
			self.timers['movies']['command'] = 'RunPlugin(plugin://' + ADDON_ID + '/?mode=autoupdate_movie)'
		else:
			self.timers['movies'] = None
			
		'''if self.update_library:
			nextrun = self.get_next_run(self.update_timer, delay=10)
			self.log("Next library update scheduled to run at %s" % nextrun)
			self.timers['library'] = {}
			self.timers['library']['lastrun'] = self.get_last_run('library')
			self.timers['library']['interval'] = self.update_timer
			self.timers['library']['nextrun'] = nextrun
			self.timers['library']['command'] = 'RunPlugin(plugin://' + ADDON_ID + '/?mode=autoupdate_library)'
		else:
			self.timers['library'] = None'''
			
	def evaluate_timers(self):
		now = self.timestamp(datetime.now())
		if self.update_tvshows:
			if now > self.timestamp(self.timers['tvshows']['nextrun']):
				self.execute('tvshows')
		if self.update_movies:
			if now > self.timestamp(self.timers['movies']['nextrun']):
				self.execute('movies')

	def execute(self, event):
		self.log("Executing: %s" % event)
		self.log(str(datetime.now()))
		self.timers[event]['lastrun'] =  datetime.now()
		self.timers[event]['nextrun'] = self.get_next_run(self.timers[event]['interval'])
		self.set_last_run(event, str(self.timers[event]['lastrun']))
		xbmc.executebuiltin(self.timers[event]['command'])
		self.log("Next %s update scheduled to run at %s" % (event, self.timers[event]['nextrun']))
		self.log("Waiting for next event...")
	
	def start(self):
		self.log("Service starting...")
		self.load_settings()
		self.clear_timers()
		self.setup_timers()
		self.run()
		
	def run(self):
		monitor = xbmc.Monitor()
		self.log("Waiting for next event...")
		while True:
			if monitor.waitForAbort(1):
				break
			if self.isPlaying() and self._tracking:
				self._current_time = self.getTime()
			if self.enabled:
				self.evaluate_timers()
			if self.enabled != self.is_enabled() :
				self.load_settings()
				self.setup_timers()
		self.log("Service stopping...")

if __name__ == '__main__':
	AC = AllucService()
	AC.start()

