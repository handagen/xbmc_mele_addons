script.module.neverwise
================

NeverWise Kodi toolkit (tested on Kodi 14.0 Helix)

You may need to download the dependencies of this addon:
- script.module.beautifulsoup 3.2.1 (http://mirrors.xbmc.org/addons/frodo/script.module.beautifulsoup/script.module.beautifulsoup-3.2.1.zip)
- script.module.parsedom 2.5.2 (http://mirrors.xbmc.org/addons/frodo/script.module.parsedom/script.module.parsedom-2.5.2.zip)
