Artist Slideshow Features
displays slideshow as background for music visualization (must use a compatible skin or
update Confluence skin using the instructions below)
  option to have artist images downloaded and/or use a local directory of artist images
  option for a fallback slideshow if no local or remote images are found
  option to have a single slideshow displayed regardless of artist playing
downloads artwork from fanart.tv, theaudiodb.com, and htbackdrops.org to display as
background for music visualization
  option to download artist bio and other additional information (skin must support
  display of this information)
  option to limit size of download cache

For a detailed description of options as well as instructions for skin and addon
integration, see:

  http://wiki.xbmc.org/index.php?title=Add-on:Artist_Slideshow